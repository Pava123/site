import { VUZ_PRACTICES_DATA } from "../data";
import { GraduationCap, BookOpen, ArrowRight, FileText } from "lucide-react";

interface SpecialtiesGridProps {
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
}

export default function SpecialtiesGrid({ onOpenOrder }: SpecialtiesGridProps) {
  // Grouped university lists for Point 2
  const alphabetGroups = [
    {
      letter: "В",
      list: [
        { name: "ВШЭ", fullName: "Высшая школа экономики", path: "/preddiplomnaya-praktika-vshe" }
      ]
    },
    {
      letter: "М",
      list: [
        { name: "МГОУ", fullName: "Московский государственный областной университет", path: "/uchebnaya-praktika-mgou" },
        { name: "МОСАП", fullName: "Московская открытая социальная академия", path: "/preddiplomnaya-praktika-mosap" },
        { name: "МПГУ", fullName: "Московский педагогический государственный университет", path: "/uchebnaya-praktika-mpgu" },
        { name: "МТИ", fullName: "Московский технологический институт", path: "/proizvodstvennaya-praktika-mti" },
        { name: "МФЮА", fullName: "Московский финансово-юридический университет", path: "" }
      ]
    },
    {
      letter: "Р",
      list: [
        { name: "Росдистант", fullName: "Тольяттинский государственный университет (ТГУ)", path: "/uchebnaya-praktika-rosdistant" },
        { name: "РУДН", fullName: "Российский университет дружбы народов", path: "/uchebnaya-praktika-rudn" },
        { name: "РЭУ им. Плеханова", fullName: "Российский экономический университет имени Г. В. Плеханова", path: "" }
      ]
    },
    {
      letter: "С",
      list: [
        { name: "Синергия", fullName: "Университет «Синергия»", path: "/uchebnaya-praktika-sinergiya" }
      ]
    }
  ];

  return (
    <section id="specialties" className="bg-white py-16 sm:py-20 font-sans border-t border-slate-100">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header section */}
        <div className="text-center space-y-3 mb-10 sm:mb-12">
          <span className="text-xs font-black uppercase tracking-widest text-[#2563EB] bg-blue-50 px-3 py-1.5 rounded-sm">
            Каталог ВУЗов РФ
          </span>
          <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-slate-900 uppercase" id="vuz-grid-title">
            РАБОТАЕМ СО ВСЕМИ ВУЗАМИ
          </h2>
          <p className="text-sm font-semibold text-slate-500 max-w-xl mx-auto leading-relaxed">
            Готовые отчёты по практике для студентов любого вуза. Оформление с печатью, доставка по России.
          </p>
        </div>

        {/* 3 columns design on desktop, 1 column on mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {VUZ_PRACTICES_DATA.map((item) => {
            // Determine representative icon: книга / диплом / градусная шапка
            let IconComponent = BookOpen;
            if (item.iconName === "FileText") {
              IconComponent = FileText;
            } else if (item.iconName === "GraduationCap") {
              IconComponent = GraduationCap;
            }
            
            return (
              <a
                key={item.id}
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onOpenOrder(item.name);
                }}
                className="group flex items-center gap-4 bg-[#f8f9fa] rounded-[12px] p-5 shadow-xs border border-transparent hover:bg-white hover:border-blue-200 hover:shadow-md hover:-translate-y-1 transition-all duration-300 cursor-pointer"
                id={`vuz-card-${item.id}`}
              >
                {/* Left Side Icon inside premium circle */}
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#2563EB] group-hover:bg-[#2563EB] group-hover:text-white transition-all duration-300">
                  <IconComponent className="h-5.5 w-5.5" />
                </div>

                {/* Right Side Texts */}
                <div className="flex-1 min-w-0 space-y-0.5">
                  <h3 className="text-sm font-extrabold text-slate-900 group-hover:text-[#2563EB] transition-colors line-clamp-2 leading-snug">
                    {item.name}
                  </h3>
                  <p className="text-xs font-semibold text-slate-400 group-hover:text-slate-600 transition-colors uppercase tracking-wider text-[10px]">
                    {item.vuz}
                  </p>
                </div>

                {/* Subtle Action Arrow */}
                <div className="shrink-0 text-slate-300 group-hover:text-[#2563EB] group-hover:translate-x-1 transition-all duration-300">
                  <ArrowRight className="h-4 w-4" />
                </div>
              </a>
            );
          })}
        </div>

        {/* Dynamic button to scroll down to alphabetical index */}
        <div className="flex justify-center mb-16">
          <button
            onClick={() => {
              const element = document.getElementById("alphabetical-index");
              if (element) {
                element.scrollIntoView({ behavior: "smooth" });
              }
            }}
            className="flex items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-extrabold text-xs py-3.5 px-6 uppercase tracking-wider transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5 cursor-pointer"
          >
            Показать все вузы
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {/* Point 2: Grouped Alphabetical Universities Index */}
        <div id="alphabetical-index" className="bg-slate-50 border border-slate-200/80 rounded-2xl p-6 sm:p-8">
          <div className="mb-6">
            <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight">
              Список ВУЗов по алфавиту
            </h3>
            <p className="text-xs font-semibold text-slate-500 mt-1">
              Выберите ваше учебное заведение для ознакомления со спецификациями или расчета стоимости
            </p>
          </div>

          <div className="columns-1 md:columns-2 gap-6 [column-fill:balance]">
            {alphabetGroups.map((group) => (
              <div 
                key={group.letter} 
                className="break-inside-avoid-column bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs flex gap-4 mb-6"
              >
                {/* Letter Index Block */}
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600 font-black text-lg border border-blue-100 shadow-xs">
                  {group.letter}
                </span>

                {/* Universities Column */}
                <div className="flex-1 space-y-4">
                  {group.list.map((univ, uIdx) => (
                    <div key={uIdx} className="group/univ flex items-start justify-between gap-3 border-b border-slate-100 last:border-none last:pb-0 pb-3">
                      <div>
                        <span 
                          onClick={() => {
                            if (univ.path) {
                              window.location.hash = univ.path;
                            } else {
                              onOpenOrder("Помощь с практикой", `ВУЗ: ${univ.name}`, false);
                            }
                          }}
                          className="text-sm font-extrabold text-slate-800 hover:text-[#2563EB] cursor-pointer transition-colors block"
                        >
                          {univ.name}
                        </span>
                        <span className="text-[11px] text-slate-500 block leading-tight">
                          {univ.fullName}
                        </span>
                      </div>
                      
                      <button
                        onClick={() => onOpenOrder("Помощь с практикой", `ВУЗ: ${univ.name}`, false)}
                        className="text-[10px] font-bold text-[#2563EB] hover:text-white border border-blue-200 hover:bg-blue-600 hover:border-blue-600 rounded-md px-2.5 py-1 bg-white transition-all shrink-0 cursor-pointer"
                      >
                        Помочь
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}

