import { useState, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Send, CheckCircle2 } from "lucide-react";

export default function CTAForm() {
  const [formData, setFormData] = useState({
    name: "",
    specialty: "",
    phone: "",
    telegram: "",
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      setError("Пожалуйста, заполните Имя и Номер телефона.");
      return;
    }
    setError("");
    setIsSubmitted(true);
  };

  return (
    <section className="relative overflow-hidden bg-slate-900 py-16 text-white">
      {/* Decorative Blur Background Circles */}
      <div className="absolute right-0 top-0 -mr-20 -mt-20 h-80 w-80 rounded-full bg-sky-500/20 blur-3xl pointer-events-none" />
      <div className="absolute left-0 bottom-0 -ml-20 -mb-20 h-80 w-80 rounded-full bg-indigo-500/20 blur-3xl pointer-events-none" />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="space-y-8 text-center max-w-3xl mx-auto">
          
          <div className="space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-sky-400 bg-sky-500/10 px-3 py-1 rounded-sm">
              Более 47 специальностей
            </span>
            <h2 className="text-2xl sm:text-3.5xl font-sans font-black tracking-tight uppercase leading-snug">
              Не нашли своё направление?
              <span className="block text-sky-400 mt-1">Оставьте заявку, специалист свяжется с Вами</span>
            </h2>
          </div>

          <AnimatePresence mode="wait">
            {!isSubmitted ? (
              <motion.form
                id="inline-cta-form"
                key="form"
                onSubmit={handleSubmit}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                {/* 4 elements input line */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <input
                      type="text"
                      placeholder="Ваше имя *"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full text-sm rounded-xl border border-slate-800 bg-slate-950/80 px-4 py-3 text-white placeholder-slate-500 focus:border-sky-400 focus:outline-hidden transition-all"
                      required
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Специальность"
                      value={formData.specialty}
                      onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
                      className="w-full text-sm rounded-xl border border-slate-800 bg-slate-950/80 px-4 py-3 text-white placeholder-slate-500 focus:border-sky-400 focus:outline-hidden transition-all"
                    />
                  </div>
                  <div>
                    <input
                      type="tel"
                      placeholder="Номер телефона *"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full text-sm rounded-xl border border-slate-800 bg-slate-950/80 px-4 py-3 text-white placeholder-slate-500 focus:border-sky-400 focus:outline-hidden transition-all"
                      required
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Telegram логин"
                      value={formData.telegram}
                      onChange={(e) => setFormData({ ...formData, telegram: e.target.value })}
                      className="w-full text-sm rounded-xl border border-slate-800 bg-slate-950/80 px-4 py-3 text-white placeholder-slate-500 focus:border-sky-400 focus:outline-hidden transition-all"
                    />
                  </div>
                </div>

                {error && <p className="text-rose-400 text-xs text-left">{error}</p>}

                {/* Submit line */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                  <p className="text-slate-400 text-xs text-left max-w-lg leading-relaxed">
                    * Нажимая кнопку, вы соглашаетесь с условиями хранения персональных данных. Наш лучший методист перезвонит за 10-15 минут, проанализирует требования и рассчитает точную оценку стоимости работы.
                  </p>
                  <button
                    type="submit"
                    className="relative overflow-hidden group/btn w-full sm:w-auto shrink-0 flex items-center justify-center gap-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white px-8 py-3.5 font-bold text-sm uppercase tracking-wider cursor-pointer shadow-lg transition-all"
                  >
                    <Send className="h-4 w-4 relative z-10 transition-transform group-hover/btn:translate-x-0.5" />
                    <span className="relative z-10">Получить консультацию</span>

                    {/* Shimmer reflection glint */}
                    <motion.span
                      initial={{ x: "-150%" }}
                      animate={{ x: "250%" }}
                      transition={{
                        repeat: Infinity,
                        repeatType: "loop",
                        duration: 3,
                        repeatDelay: 2.8,
                        ease: "easeInOut",
                      }}
                      className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-20 pointer-events-none z-10"
                    />
                  </button>
                </div>
              </motion.form>
            ) : (
              <motion.div
                id="inline-cta-success"
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="rounded-2xl border border-sky-500/30 bg-sky-500/5 p-6 max-w-xl mx-auto space-y-3"
              >
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-sky-505/20 text-sky-400">
                  <CheckCircle2 className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold">Заявка на консультацию отправлена!</h3>
                <p className="text-sm text-slate-300">
                  Методист <b>{formData.name}</b> зафиксировал заявку по профилю <b>{formData.specialty || "Общий профиль"}</b>. Мы позвоним вам на номер <b>{formData.phone}</b> в течение 10 минут. Будьте на связи!
                </p>
                <button
                  onClick={() => {
                    setIsSubmitted(false);
                    setFormData({ name: "", specialty: "", phone: "", telegram: "" });
                  }}
                  className="text-xs bg-white/10 text-sky-200 px-4 py-2 rounded-lg hover:bg-white/20 transition-all cursor-pointer"
                >
                  Оформить новую заявку
                </button>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
      </div>
    </section>
  );
}
