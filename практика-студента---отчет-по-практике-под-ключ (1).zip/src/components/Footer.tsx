import { GraduationCap, Mail, Phone, ChevronRight } from "lucide-react";
import { FOOTER_TAGS, CONTACT_INFO } from "../data";
import Logo from "./Logo";

interface FooterProps {
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
}

export default function Footer({ onOpenOrder }: FooterProps) {
  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-slate-900 text-slate-400 font-sans">
      
      {/* Upper Main Footer Grid */}
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-12">
          
          {/* Column 1: Logo & Company Disclaimer */}
          <div className="space-y-4 md:col-span-5">
            <div className="flex items-center gap-2.5">
              <Logo light={true} />
            </div>
            
            <p className="text-xs sm:text-xs leading-relaxed text-slate-400 max-w-md">
              Мы не рекламируем противозаконные услуги по фальсификации результатов. Сервис оказывает исключительно качественные образовательные, репетиторские, методические и консультационные услуги для успешного прохождения практики студентами в реальных организациях.
            </p>
            <p className="text-[10px] text-slate-500">
              © 2016-{new Date().getFullYear()} Практика Студента. Все права защищены.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-4 md:col-span-3">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Навигация
            </h4>
            <ul className="space-y-2.5 text-xs font-semibold">
              {[
                { name: "Главная", href: "#hero" },
                { name: "Учебные направления", href: "#services" },
                { name: "Специальности", href: "#specialties" },
                { name: "Видео отзывы", href: "#reviews" },
                { name: "Как пройти практику", href: "#how-to" },
                { name: "Наши гарантии", href: "#why-us" },
              ].map((link) => (
                <li key={link.name}>
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="flex items-center gap-1 hover:text-sky-400 transition-colors cursor-pointer text-left"
                  >
                    <ChevronRight className="h-3.5 w-3.5 text-slate-600" />
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Contact details */}
          <div className="space-y-4 md:col-span-4">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Контакты
            </h4>
            
            <div className="space-y-3.5">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Отдел заботы:</span>
                <a
                  href={`tel:${CONTACT_INFO.primaryPhoneLink}`}
                  className="flex items-center gap-2 text-sm sm:text-base font-extrabold text-white hover:text-sky-400 transition-colors"
                >
                  <Phone className="h-4 w-4 text-sky-500" />
                  {CONTACT_INFO.primaryPhone}
                </a>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Электронная почта:</span>
                <a
                  href={`mailto:${CONTACT_INFO.email}`}
                  className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-300 hover:text-sky-400 transition-colors"
                >
                  <Mail className="h-3.5 w-3.5 text-sky-500" />
                  {CONTACT_INFO.email}
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Lower Tag Cloud Footer Section */}
        <div className="border-t border-slate-800 mt-12 pt-10 space-y-4">
          <span className="text-xs uppercase font-extrabold tracking-wider text-slate-300 block">
            Часто ищут / Популярные услуги
          </span>
          <div className="flex flex-wrap gap-2 pt-1">
            {FOOTER_TAGS.map((tag) => (
              <button
                key={tag}
                onClick={() => onOpenOrder(`Отчет по практике`, tag, false)}
                className="rounded-full border border-slate-800 bg-slate-950/40 py-1.5 px-3.5 text-xs font-medium text-slate-400 hover:border-sky-500 hover:text-sky-400 hover:bg-slate-900 transition-all cursor-pointer"
              >
                #{tag}
              </button>
            ))}
          </div>
        </div>

      </div>
    </footer>
  );
}
