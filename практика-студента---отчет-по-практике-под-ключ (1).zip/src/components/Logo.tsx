import React from "react";

interface LogoProps {
  className?: string;
  light?: boolean;
}

export default function Logo({ className = "", light = false }: LogoProps) {
  return (
    <div className={`flex flex-col select-none leading-none font-sans ${className}`}>
      {/* Top blue bar - offset properly to accent the start of the word */}
      <div className="h-[3.5px] w-[80px] bg-[#2563EB] mb-[4px] self-start" />
      
      <div className="flex flex-col font-black uppercase">
        {/* "ПРАКТИКА" in extra bold/black */}
        <span 
          className={`text-[17px] sm:text-[18px] font-black leading-none tracking-[0.07em] ${
            light ? "text-white" : "text-slate-900"
          }`}
        >
          ПРАКТИКА
        </span>
        
        {/* "СТУДЕНТА" + slanted blue slash */}
        <div className="relative flex items-center mt-[3px]">
          <span 
            className={`text-[17px] sm:text-[18px] font-black leading-none tracking-[0.07em] ${
              light ? "text-white" : "text-slate-900"
            }`}
          >
            СТУДЕНТА
          </span>
          {/* Slanted slash matching the angle in the logo */}
          <div className="h-[14px] w-[4px] bg-[#2563EB] ml-[3px] -skew-x-[22deg]" />
        </div>
      </div>
    </div>
  );
}
