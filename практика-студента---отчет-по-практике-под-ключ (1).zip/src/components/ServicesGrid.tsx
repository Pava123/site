import { useState } from "react";
import { SERVICES_DATA } from "../data";
import { ArrowUpRight, Calculator, Calendar } from "lucide-react";
import { motion } from "motion/react";

interface ServicesGridProps {
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
}

export default function ServicesGrid({ onOpenOrder }: ServicesGridProps) {
  const [activeCategory, setActiveCategory] = useState<"practice" | "course_diploma" | "exams_tests" | "consulting">("practice");

  const categories = [
    { id: "practice", label: "Отчеты по практике" },
    { id: "course_diploma", label: "Курсовые и дипломные" },
    { id: "exams_tests", label: "Экзамены и тесты" },
    { id: "consulting", label: "Консультации" }
  ] as const;

  const filteredServices = SERVICES_DATA.filter(
    (service) => service.category === activeCategory
  );

  return (
    <section id="services" className="bg-slate-50 py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header Title */}
        <div className="text-center space-y-3 mb-10 sm:mb-12">
          <span className="text-xs font-bold uppercase tracking-widest text-sky-500 bg-sky-500/10 px-3 py-1 rounded-sm">
            Цена практики по запросу
          </span>
          <h2 className="text-2.5xl sm:text-4xl font-sans font-black tracking-tight text-slate-900 uppercase">
            Услуги и цены под ключ
          </h2>
          <p className="text-sm font-medium text-slate-500 max-w-lg mx-auto">
            Подберем оптимальный тариф и окажем квалифицированную помощь строго по регламенту вашей кафедры
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10 max-w-4xl mx-auto">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold uppercase tracking-wider transition-all cursor-pointer border ${
                activeCategory === cat.id
                  ? "bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/10"
                  : "bg-white text-slate-700 hover:text-slate-950 border-slate-200 hover:border-slate-300"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Dynamic Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8 justify-center">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-lg hover:border-sky-500 hover:shadow-sky-500/15 hover:-translate-y-1 transition-all duration-300 min-h-[380px]"
            >
              {/* Background student image */}
              {service.imageUrl && (
                <div className="absolute inset-0 z-0 select-none pointer-events-none overflow-hidden rounded-2xl">
                  <img
                    src={service.imageUrl}
                    alt={service.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover opacity-20 group-hover:scale-105 group-hover:opacity-30 transition-all duration-500"
                  />
                  {/* Overlay gradient overlay */}
                  <div className={`absolute inset-0 bg-gradient-to-t ${service.bgGradient || 'from-slate-950/95 via-slate-950/90 to-slate-900/80'}`} />
                </div>
              )}

              {/* Card top action */}
              <div className="relative z-10 space-y-4">
                <div className="flex items-start justify-between">
                  <span className="text-[10px] bg-sky-500/20 text-sky-300 font-extrabold px-2 py-0.5 rounded-sm border border-sky-500/30">
                    {service.badge}
                  </span>
                  <div className="rounded-full bg-slate-800/80 p-1.5 text-slate-400 group-hover:bg-sky-500 group-hover:text-white transition-all duration-300">
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-base font-black text-white group-hover:text-sky-400 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed min-h-[64px]">
                    {service.description}
                  </p>
                </div>
              </div>

              {/* Price level & CTA */}
              <div className="relative z-10 border-t border-slate-800/60 mt-4 pt-4 space-y-3.5">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-400">Стоимость:</span>
                  <span className="text-sky-400 font-extrabold text-sm">{service.priceText}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-400">Сроки:</span>
                  <span className="text-slate-200 flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5 text-slate-400" />
                    {service.durationText}
                  </span>
                </div>

                <button
                  onClick={() => onOpenOrder(service.title, "", false)}
                  className="relative overflow-hidden group/btn w-full flex items-center justify-center gap-2 rounded-xl bg-sky-500 text-white font-bold py-3 text-xs uppercase tracking-wider hover:bg-sky-600 active:bg-sky-700 cursor-pointer shadow-md transition-all"
                >
                  <Calculator className="h-3.5 w-3.5 shrink-0 transition-transform group-hover/btn:scale-110" />
                  Узнать цену
                  
                  {/* Shimmer reflection glint */}
                  <motion.span
                    initial={{ x: "-150%" }}
                    animate={{ x: "250%" }}
                    transition={{
                      repeat: Infinity,
                      repeatType: "loop",
                      duration: 3,
                      repeatDelay: 1,
                      ease: "easeInOut",
                    }}
                    className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-20 pointer-events-none z-10"
                  />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
