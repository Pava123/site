import { useState } from "react";
import { BookOpen, Calendar, ArrowRight, BookmarkCheck, LayoutGrid, ChevronLeft, ChevronRight } from "lucide-react";
import { EXTRACTED_ARTICLES, ExtractedArticle } from "../extractedArticles";

export default function PlaceholderSections() {
  // We'll separate our Articles database into two main types
  const usefulArticles = EXTRACTED_ARTICLES.filter(
    (art) => art.category === "ПОЛЕЗНЫЕ СТАТЬИ"
  );
  
  const otherWorks = EXTRACTED_ARTICLES.filter(
    (art) => art.category === "ДРУГИЕ ВИДЫ РАБОТ"
  );

  // Pagination states for "ПОЛЕЗНЫЕ СТАТЬИ" (2 per page to demonstrate pagination clearly)
  const [articlesPage, setArticlesPage] = useState(1);
  const articlesPerPage = 2;
  const totalArticlesPages = Math.ceil(usefulArticles.length / articlesPerPage);
  const paginatedArticles = usefulArticles.slice(
    (articlesPage - 1) * articlesPerPage,
    articlesPage * articlesPerPage
  );

  // Pagination states for "ДРУГИЕ ВИДЫ РАБОТ" (4 per page)
  const [worksPage, setWorksPage] = useState(1);
  const worksPerPage = 4;
  const totalWorksPages = Math.ceil(otherWorks.length / worksPerPage);
  const paginatedWorks = otherWorks.slice(
    (worksPage - 1) * worksPerPage,
    worksPage * worksPerPage
  );

  return (
    <div id="dynamic-crawled-sections" className="bg-[#FAF9F6] py-16 sm:py-20 font-sans border-t border-slate-105">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-20">
        
        {/* SECTION 1: ПОЛЕЗНЫЕ СТАТЬИ (Dynamic with Pagination) */}
        <section id="useful-articles" className="space-y-8 sm:space-y-10 scroll-mt-24">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-100 pb-5">
            <div className="space-y-2 text-left">
              <span className="text-xs font-black uppercase tracking-widest text-[#2563EB] bg-blue-50 px-3 py-1.5 rounded-sm">
                База знаний
              </span>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-950 uppercase">
                ПОЛЕЗНЫЕ СТАТЬИ
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-500 max-w-xl leading-relaxed">
                Пошаговые методические рекомендации, секреты легкой защиты, требования плагиата в МТИ и Синергии.
              </p>
            </div>

            {/* Pagination Controls */}
            {totalArticlesPages > 1 && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">
                  Страница {articlesPage} из {totalArticlesPages}
                </span>
                <div className="flex items-center gap-1">
                  <button
                    disabled={articlesPage === 1}
                    onClick={() => setArticlesPage(articlesPage - 1)}
                    className="p-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:border-blue-400 disabled:opacity-50 transition-all cursor-pointer"
                    aria-label="Предыдущая страница"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  {[...Array(totalArticlesPages)].map((_, i) => {
                    const p = i + 1;
                    return (
                      <button
                        key={p}
                        onClick={() => setArticlesPage(p)}
                        className={`w-8 h-8 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          articlesPage === p
                            ? "bg-[#2563EB] text-white shadow-xs"
                            : "bg-white border border-slate-200 text-slate-650 hover:border-blue-400"
                        }`}
                      >
                        {p}
                      </button>
                    );
                  })}
                  <button
                    disabled={articlesPage === totalArticlesPages}
                    onClick={() => setArticlesPage(articlesPage + 1)}
                    className="p-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:border-blue-400 disabled:opacity-50 transition-all cursor-pointer"
                    aria-label="Следующая страница"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Articles grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {paginatedArticles.map((art) => (
              <div 
                key={art.url}
                className="group relative flex flex-col justify-between bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 hover:border-blue-300 hover:shadow-xl transition-all duration-300 overflow-hidden"
              >
                <div className="space-y-5">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-blue-50 text-[#2563EB] group-hover:bg-[#2563EB] group-hover:text-white transition-all duration-300 shadow-xs">
                    <BookOpen className="h-5.5 w-5.5" />
                  </div>
                  
                  <div className="space-y-2">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {art.publishDate}
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 leading-snug group-hover:text-[#2563EB] transition-colors">
                      {art.h1}
                    </h3>
                    <p className="text-xs font-semibold text-slate-500 leading-relaxed">
                      {art.summary}
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex flex-wrap gap-1.5">
                    {art.keywords.slice(0, 3).map((kw, i) => (
                      <span key={i} className="text-[9px] bg-slate-50 border border-slate-100 font-extrabold text-slate-400 px-2 py-0.5 rounded-md">
                        #{kw}
                      </span>
                    ))}
                  </div>
                  <a 
                    href={`#${art.url}`}
                    className="flex items-center gap-1 text-xs font-black text-[#2563EB] hover:text-blue-700 uppercase tracking-wider shrink-0"
                  >
                    <span>Читать полностью</span>
                    <ArrowRight className="h-3 w-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 2: ДРУГИЕ ВИДЫ РАБОТ (Dynamic with Pagination) */}
        <section id="other-works" className="space-y-8 sm:space-y-10 scroll-mt-24">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-105 pb-5">
            <div className="space-y-2 text-left">
              <span className="text-xs font-black uppercase tracking-widest text-[#2563EB] bg-blue-50 px-3 py-1.5 rounded-sm">
                Каталог услуг
              </span>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-950 uppercase">
                ДРУГИЕ ВИДЫ РАБОТ
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-500 max-w-xl leading-relaxed">
                Профессиональная помощь в составлении курсовых работ, ВКР бакалавра, НИР, лабораторных работ и прохождении трудных онлайн тестов в СДО.
              </p>
            </div>

            {/* Pagination Controls */}
            {totalWorksPages > 1 && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">
                  Страница {worksPage} из {totalWorksPages}
                </span>
                <div className="flex items-center gap-1">
                  <button
                    disabled={worksPage === 1}
                    onClick={() => setWorksPage(worksPage - 1)}
                    className="p-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:border-blue-400 disabled:opacity-50 transition-all cursor-pointer"
                    aria-label="Предыдущая страница"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  {[...Array(totalWorksPages)].map((_, i) => {
                    const p = i + 1;
                    return (
                      <button
                        key={p}
                        onClick={() => setWorksPage(p)}
                        className={`w-8 h-8 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          worksPage === p
                            ? "bg-[#2563EB] text-white shadow-xs"
                            : "bg-white border border-slate-200 text-slate-650 hover:border-blue-400"
                        }`}
                      >
                        {p}
                      </button>
                    );
                  })}
                  <button
                    disabled={worksPage === totalWorksPages}
                    onClick={() => setWorksPage(worksPage + 1)}
                    className="p-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:border-blue-400 disabled:opacity-50 transition-all cursor-pointer"
                    aria-label="Следующая страница"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Works Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {paginatedWorks.map((work) => (
              <div 
                key={work.url}
                className="group relative flex flex-col justify-between bg-white rounded-2xl p-6 border border-slate-200/80 hover:border-blue-300 hover:shadow-xl transition-all duration-300 overflow-hidden"
              >
                <div className="space-y-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#2563EB] group-hover:bg-[#2563EB] group-hover:text-white transition-all duration-300 shadow-xs">
                    <BookmarkCheck className="h-5 w-5" />
                  </div>
                  
                  <div className="space-y-1.5">
                    <h3 className="text-sm font-extrabold text-slate-900 group-hover:text-[#2563EB] transition-colors leading-snug">
                      {work.h1}
                    </h3>
                    <p className="text-[11px] font-semibold text-slate-400 leading-relaxed line-clamp-3">
                      {work.summary}
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] text-emerald-600 font-extrabold flex items-center gap-1 uppercase tracking-wide">
                    <LayoutGrid className="h-3.5 w-3.5" />
                    <span>ГОСТ 2026</span>
                  </span>
                  <a 
                    href={`#${work.url}`}
                    className="flex items-center gap-1 text-[10px] font-black text-[#2563EB] hover:text-blue-700 uppercase tracking-widest shrink-0"
                  >
                    <span>Перейти</span>
                    <ArrowRight className="h-3 w-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
}
