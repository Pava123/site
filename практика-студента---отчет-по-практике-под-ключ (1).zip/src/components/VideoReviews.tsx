import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, Pause, Volume2, Star, ThumbsUp, MessageCircle, ExternalLink, HelpCircle, Check, X } from "lucide-react";
import { VIDEO_REVIEWS_DATA } from "../data";

interface TextReview {
  id: string;
  name: string;
  vuz: string;
  specialty: string;
  rating: number;
  text: string;
  date: string;
}

export default function VideoReviews() {
  const [playingVideoId, setPlayingVideoId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackProgress, setPlaybackProgress] = useState(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const startVideoSimulation = (id: string) => {
    setPlayingVideoId(id);
    setIsPlaying(true);
    setPlaybackProgress(0);

    // Simulate progress bar timer
    const interval = setInterval(() => {
      setPlaybackProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsPlaying(false);
          return 100;
        }
        return prev + 1;
      });
    }, 450);
  };

  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
  };

  const textReviews: TextReview[] = [
    {
      id: "tr-1",
      name: "Екатерина Морозова",
      vuz: "Университет «Синергия»",
      specialty: "Менеджмент организации",
      rating: 5,
      text: "Заказывала здесь подробный отчет по производственной практике. Сделали безупречно быстро, прикрепили все заполненные дневники и договоры с мокрой синей печатью. Преподаватель на кафедре принял без единого замечания!",
      date: "Вчера"
    },
    {
      id: "tr-2",
      name: "Артем Попов",
      vuz: "Московский технологический институт (МТИ)",
      specialty: "Электроэнергетика и электротехника",
      rating: 5,
      text: "Очень горели финальные сроки сдачи отчета по учебной практике. Ребята оформили все документы буквально за сутки! Уникальность текста в системе Антиплагиат.ВУЗ составила 87%, что намного выше нормы. Огромное спасибо!",
      date: "3 дня назад"
    },
    {
      id: "tr-3",
      name: "Владислав Воронов",
      vuz: "Росдистант (ТГУ)",
      specialty: "Юриспруденция и гражданское право",
      rating: 5,
      text: "Ознакомительная практика сделана под ключ с оригинальной печатью правового центра. Дневник подробно заполнен по каждому рабочему дню, характеристика безупречная. Сдал сессию и закрыл долги за пару минут.",
      date: "5 дней назад"
    },
    {
      id: "tr-4",
      name: "Ксения Новикова",
      vuz: "Московская открытая социальная академия (МОСАП)",
      specialty: "Государственное и муниципальное управление",
      rating: 5,
      text: "Покупала готовый отчет по преддипломной практике. Все балансы сошлись, выводы и графики обоснованы. Занесли оригиналы бумаг курьером СДЭК прямо домой. Куратор в диком восторге! Рекомендую всем студентам.",
      date: "1 неделю назад"
    },
    {
      id: "tr-5",
      name: "Дмитрий Киселев",
      vuz: "Университет «Синергия»",
      specialty: "Информационные системы и технологии",
      rating: 5,
      text: "Великолепный сервис! Помогли закрыть зачеты и тесты в ЛК под ключ, и написали сложнейшую педагогическую практику. Менеджеры всегда на связи в WhatsApp, вежливо дают консультации по любым учебным вопросам.",
      date: "2 недели назад"
    },
    {
      id: "tr-6",
      name: "Анна Савельева",
      vuz: "Московский финансово-юридический университет (МФЮА)",
      specialty: "Бухгалтерский учет, анализ и аудит",
      rating: 5,
      text: "Мой отчет по преддипломной практике и дипломная работа были защищены на высшую оценку. Замечания профессора по оформлению формул исправлялись авторами сразу же, абсолютно бесплатно. Настоящие профессионалы своего дела!",
      date: "1 месяц назад"
    }
  ];

  return (
    <section id="reviews" className="bg-slate-50 py-20 sm:py-24 relative">
      {/* Toast Notification Container */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 bg-slate-900 border border-slate-800 text-white p-4 rounded-xl shadow-2xl z-50 flex items-start gap-3"
          >
            <div className="rounded-full bg-emerald-500/20 text-emerald-400 p-1 shrink-0 mt-0.5">
              <Check className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Уведомление</p>
              <p className="text-xs sm:text-sm text-slate-200 mt-1 font-semibold leading-snug">{toastMessage}</p>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="text-slate-400 hover:text-white shrink-0 p-1 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header content */}
        <div className="text-center space-y-3 mb-12 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-[#2563EB] bg-blue-500/10 px-3 py-1 rounded-sm">
            Только реальные отзывы студентов
          </span>
          <h2 className="text-2.5xl sm:text-4xl font-sans font-black tracking-tight text-slate-900 uppercase">
            ВИДЕО ОТЗЫВЫ
          </h2>
          <p className="text-sm font-medium text-slate-500 max-w-lg mx-auto">
            Посмотрите искренние видеоотчёты студентов, у которых мы благополучно закрыли сессии
          </p>
        </div>

        {/* 2 Big Video Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-20">
          {VIDEO_REVIEWS_DATA.map((rev) => {
            const isCurrentPlaying = playingVideoId === rev.id;

            return (
              <div
                key={rev.id}
                className="overflow-hidden rounded-2xl bg-white border border-slate-100 shadow-xs hover:shadow-lg transition-all"
              >
                {/* Video Stage / Cover */}
                <div className="relative aspect-video bg-slate-950 overflow-hidden">
                  <AnimatePresence mode="wait">
                    {!isCurrentPlaying ? (
                      <motion.div
                        key="cover"
                        initial={{ opacity: 1 }}
                        className="absolute inset-0"
                      >
                        <img
                          src={rev.videoPoster}
                          alt={rev.studentName}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover filter brightness-90 group-hover:scale-105 transition-all"
                        />
                        {/* Dark shield */}
                        <div className="absolute inset-0 bg-slate-950/40" />

                        {/* Centered Play Button */}
                        <button
                          onClick={() => startVideoSimulation(rev.id)}
                          className="absolute inset-x-0 inset-y-0 m-auto flex h-16 w-16 items-center justify-center rounded-full bg-sky-500 text-white shadow-xl hover:scale-110 active:scale-95 transition-all cursor-pointer"
                          aria-label={`Воспроизвести отзыв от ${rev.studentName}`}
                        >
                          <Play className="h-8 w-8 text-white fill-white ml-1" />
                        </button>

                        {/* Badges on video cover */}
                        <div className="absolute bottom-3 right-3 rounded-md bg-slate-950/80 px-2 py-1 text-xs font-mono text-white">
                          {rev.videoDuration}
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="player"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 flex flex-col justify-between p-4 bg-slate-950"
                      >
                        {/* Video Top Controls */}
                        <div className="flex items-center justify-between text-xs text-slate-400 z-10 bg-gradient-to-b from-slate-950 to-transparent p-2">
                          <span className="flex items-center gap-1.5 text-sky-400">
                            <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                            LIVE Плеер
                          </span>
                          <span>{rev.videoDuration}</span>
                        </div>

                        {/* Interactive Dynamic Subtitle Banner */}
                        <div className="p-3 text-center text-xs sm:text-sm text-sky-300 font-medium max-w-md mx-auto z-10 bg-slate-900/90 rounded-xl border border-sky-500/10 shadow-lg">
                          {isPlaying ? (
                            <span>« {rev.reviewText.slice(0, Math.floor((playbackProgress / 100) * rev.reviewText.length) + 6)}... »</span>
                          ) : (
                            <span className="text-slate-400">Плеер приостановлен</span>
                          )}
                        </div>

                        {/* Video Bottom Custom Controls */}
                        <div className="space-y-2 z-10 bg-gradient-to-t from-slate-950 to-transparent p-2">
                          {/* Progress Line */}
                          <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-sky-500 transition-all duration-300"
                              style={{ width: `${playbackProgress}%` }}
                            />
                          </div>

                          <div className="flex items-center justify-between text-white">
                            <div className="flex items-center gap-3">
                              <button
                                onClick={togglePlayback}
                                className="p-1 rounded-sm hover:bg-white/15 text-white cursor-pointer"
                              >
                                {isPlaying ? <Pause className="h-5 w-5 fill-white" /> : <Play className="h-5 w-5 fill-white" />}
                              </button>
                              <Volume2 className="h-4 w-4 text-slate-400" />
                            </div>
                            <span className="text-xs font-mono text-slate-400">
                              {Math.floor((playbackProgress / 100) * 84)}s / 84s
                            </span>
                            <button
                              onClick={() => setPlayingVideoId(null)}
                              className="text-xs text-sky-400 hover:text-sky-300 cursor-pointer font-semibold"
                            >
                              Закрыть плеер
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Sub-Card Review Details */}
                <div className="p-6 space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-extrabold text-slate-950 text-base">{rev.studentName}</h3>
                      <p className="text-xs text-slate-400 font-semibold">{rev.universityName} • {rev.specialty}</p>
                    </div>
                    <div className="flex items-center gap-0.5 bg-sky-500/10 rounded-lg py-1 px-2.5 text-sky-600 font-black text-xs">
                      <Star className="h-3.5 w-3.5 fill-sky-500 text-sky-500" />
                      5.0
                    </div>
                  </div>

                  <p className="text-slate-600 text-sm leading-relaxed italic">
                    {rev.reviewText}
                  </p>

                  <div className="flex items-center gap-4 text-slate-400 text-xs border-t border-slate-50 pt-4">
                    <span className="flex items-center gap-1"><ThumbsUp className="h-3.5 w-3.5" /> 42 Нравится</span>
                    <span className="flex items-center gap-1"><MessageCircle className="h-3.5 w-3.5" /> 8 Комментариев</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Text Reviews Grid */}
        <div className="mt-16 border-t border-slate-200/60 pt-16">
          <div className="text-center space-y-2 mb-10">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 uppercase tracking-tight">
              ОТЗЫВЫ В ТЕКСТОВОМ ФОРМАТЕ
            </h3>
            <p className="text-xs sm:text-sm font-semibold text-slate-500 max-w-md mx-auto">
              Реальные скриншоты и благодарности от студентов, успешно сдавших свои практики и сессии
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {textReviews.map((tr) => (
              <div
                key={tr.id}
                className="bg-white rounded-2xl border border-slate-200/60 p-5 shadow-xs hover:border-slate-300 hover:shadow-md transition-all duration-300 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Rating Stars */}
                  <div className="flex items-center gap-0.5 text-amber-500">
                    {[...Array(tr.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-amber-500 text-amber-500" />
                    ))}
                  </div>

                  {/* Review Text */}
                  <p className="text-xs sm:text-sm leading-relaxed text-slate-600 italic">
                    « {tr.text} »
                  </p>
                </div>

                {/* Sub Metadata info */}
                <div className="border-t border-slate-100 mt-4 pt-4 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-extrabold text-slate-900">{tr.name}</h4>
                    <p className="text-[10px] text-[#2563EB] font-bold uppercase tracking-wider">{tr.vuz}</p>
                    <p className="text-[10px] text-slate-400 font-medium">{tr.specialty}</p>
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400 shrink-0 bg-slate-100 rounded-md px-2 py-0.5">
                    {tr.date}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Under-video informational links */}
        <div className="mt-16 text-center space-y-4 max-w-2xl mx-auto p-4">
          <p className="text-xs sm:text-sm text-slate-500 font-medium leading-relaxed">
            Хотите увидеть больше отзывов? Переходите в нашу группу ВКонтакте. Мы гордимся тем, что за <span className="text-blue-600 font-black underline">10 лет безупречной работы</span> не получили ни одного негативного отзыва от заказчиков!
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href="https://vk.com/praktika_studenta"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs py-3.5 px-6 uppercase tracking-wider transition-all"
            >
              <ExternalLink className="h-4 w-4" />
              Посмотреть отзывы в ВК
            </a>
            <button
              onClick={() => setToastMessage("Спасибо за вашу инициативу! Интерактивная веб-форма станет доступна сразу же после успешного выполнения и успешной защиты Вашего первого заказа.")}
              className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs py-3.5 px-6 uppercase tracking-wider transition-all cursor-pointer"
            >
              <HelpCircle className="h-4 w-4" />
              Написать отзыв
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
