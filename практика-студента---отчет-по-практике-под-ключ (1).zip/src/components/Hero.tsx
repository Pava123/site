import { motion } from "motion/react";
import { Clock, ShieldCheck, Award, FileCheck2, ArrowRight, Percent, Landmark } from "lucide-react";

interface HeroProps {
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
}

export default function Hero({ onOpenOrder }: HeroProps) {
  const features = [
    {
      icon: Clock,
      title: "Срочные заказы",
      desc: "в течение 4 часов",
      accent: "text-amber-400 bg-amber-500/10",
    },
    {
      icon: FileCheck2,
      title: "Печать и подпись",
      desc: "в реальной организации",
      accent: "text-emerald-400 bg-emerald-500/10",
    },
    {
      icon: Award,
      title: "До 98% уникальности",
      desc: "по \"Антиплагиат\"",
      accent: "text-sky-400 bg-sky-500/10",
    },
    {
      icon: ShieldCheck,
      title: "Гарантия качества",
      desc: "100% возврат денег",
      accent: "text-indigo-400 bg-indigo-500/10",
    },
  ];

  return (
    <section id="hero" className="relative min-h-[90vh] flex items-center overflow-hidden bg-slate-950 py-16 sm:py-24">
      {/* Background Image Layer */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/graduation_hero_1779548460555.png"
          alt="Выпускники"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-30 select-none scale-105 pointer-events-none"
        />
        {/* Deep dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/90 to-slate-900/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/70 via-transparent to-slate-950/70" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-4xl space-y-8">
          
          {/* Pill Badge */}
          <div className="inline-flex items-center gap-1.5 rounded-full bg-sky-500/10 px-3.5 py-1.5 border border-sky-500/20">
            <span className="flex h-2 w-2 rounded-full bg-sky-400 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-widest text-sky-400">Недорого</span>
          </div>

          {/* Heading */}
          <div className="space-y-4">
            <h1 className="text-3.5xl sm:text-5xl lg:text-5.5xl font-sans font-black tracking-tight text-white uppercase leading-none">
              КУПИТЬ ВСЕ ВИДЫ УЧЕБНЫХ РАБОТ В ОРГАНИЗАЦИИ С ПЕЧАТЬЮ И ПОДПИСЬЮ
            </h1>
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl font-medium leading-relaxed">
              Быстрый и эффективный способ сдать все в срок. Доверь свою работу экспертам <span className="text-sky-400 font-bold">Практика Студента</span> и занимайся тем, что тебе действительно нравится.
            </p>
          </div>

          {/* Features Grid layout */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4">
            {features.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3.5 rounded-xl bg-slate-900/80 border border-slate-800/60 p-4 shadow-sm"
              >
                <div className={`p-2.5 rounded-lg shrink-0 ${item.accent}`}>
                  <item.icon className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm sm:text-base">{item.title}</h4>
                  <p className="text-slate-400 text-xs mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Buttons CTA */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
            <button
              onClick={() => onOpenOrder("Заявка со скидкой 15%", "", true)}
              className="relative overflow-hidden group flex items-center justify-center gap-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold px-6 py-4 shadow-lg hover:shadow-emerald-500/25 active:scale-98 cursor-pointer transition-all"
            >
              <Percent className="h-5 w-5" />
              <span className="relative z-10">Получить скидку на 1-й заказ</span>
              <ArrowRight className="h-4 w-4 relative z-10" />

              {/* Shimmer reflection glint */}
              <motion.span
                initial={{ x: "-150%" }}
                animate={{ x: "250%" }}
                transition={{
                  repeat: Infinity,
                  repeatType: "loop",
                  duration: 2.5,
                  repeatDelay: 2,
                  ease: "easeInOut",
                }}
                className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-20 pointer-events-none z-10"
              />
            </button>

            <button
              onClick={() => onOpenOrder("Оплата по счету / услуге", "", false)}
              className="relative overflow-hidden group flex items-center justify-center gap-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold px-6 py-4 shadow-lg hover:shadow-sky-500/25 active:scale-98 cursor-pointer transition-all"
            >
              <Landmark className="h-5 w-5" />
              <span className="relative z-10">Оплатить услугу</span>

              {/* Shimmer reflection glint */}
              <motion.span
                initial={{ x: "-150%" }}
                animate={{ x: "250%" }}
                transition={{
                  repeat: Infinity,
                  repeatType: "loop",
                  duration: 2.5,
                  repeatDelay: 3.5,
                  ease: "easeInOut",
                }}
                className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/35 to-transparent -skew-x-20 pointer-events-none z-10"
              />
            </button>
          </div>

        </div>
      </div>
    </section>
  );
}
