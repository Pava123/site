import { Shield, Sparkles, Receipt, Percent } from "lucide-react";
import { motion } from "motion/react";

interface WhyChooseUsProps {
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
}

export default function WhyChooseUs({ onOpenOrder }: WhyChooseUsProps) {
  const points = [
    {
      icon: Shield,
      title: "Официальное оформление с синей печатью",
      desc: "Вы получаете полный комплект документов (договор, дневник практики, развернутый отзыв-характеристику) с мокрой синей печатью реально действующей компании.",
      border: "border-sky-500/20",
      accent: "text-sky-400 bg-sky-500/10",
    },
    {
      icon: Sparkles,
      title: "Бесплатные корректировки до защиты",
      desc: "Если куратор или научрук кафедры вернет отчет на доработку или выдаст замечания по оформлению, мы оперативно и бесплатно внесем исправления.",
      border: "border-violet-500/20",
      accent: "text-violet-400 bg-violet-500/10",
    },
    {
      icon: Receipt,
      title: "Быстрая доставка оригиналов СДЭКом",
      desc: "В любой город России мы бесплатно и оперативно отправляем оригиналы документов курьерской службой СДЭК или почтой. Качественные сканы вышлем в день оплаты.",
      border: "border-emerald-500/20",
      accent: "text-emerald-400 bg-emerald-500/10",
    },
  ];

  return (
    <section id="why-us" className="relative overflow-hidden bg-slate-950 py-20 sm:py-24">
      {/* Background Library Overlay Layer */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/college_library_1779548480148.png"
          alt="Учеба и библиотека"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-25 scale-102 pointer-events-none"
        />
        <div className="absolute inset-0 bg-slate-950/92" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header content Titles */}
        <div className="text-center space-y-3 mb-12 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-sky-400 bg-sky-500/10 px-3 py-1 rounded-sm">
            Гарантия на все наши услуги
          </span>
          <h2 className="text-2.5xl sm:text-4xl font-sans font-black tracking-tight text-white uppercase">
            Почему нас выбирают студенты?
          </h2>
          <p className="text-sm font-medium text-slate-400 max-w-lg mx-auto">
            Оказываем легальную помощь в подготовке отчетностей и защите студенческих квалификационных работ
          </p>
        </div>

        {/* 3 Grid Guaranteed Columns */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-12">
          {points.map((pt, idx) => (
            <div
              key={idx}
              className={`flex flex-col rounded-2xl border ${pt.border} bg-slate-900/60 p-6 backdrop-blur-md space-y-4`}
            >
              <div className={`p-3 rounded-xl w-fit ${pt.accent}`}>
                <pt.icon className="h-6 w-6" />
              </div>
              <div className="space-y-2">
                <h3 className="text-base sm:text-lg font-extrabold text-white leading-tight">
                  {pt.title}
                </h3>
                <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                  {pt.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Single central CTA Green button */}
        <div className="flex justify-center">
          <button
            onClick={() => onOpenOrder("Запрос скидки 15%", "", true)}
            className="relative overflow-hidden group flex items-center gap-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold px-8 py-4 shadow-lg hover:shadow-emerald-500/20 active:scale-98 transition-all cursor-pointer"
          >
            <Percent className="h-5 w-5 relative z-10" />
            <span className="relative z-10">Получить скидку на 1-й заказ</span>

            {/* Shimmer reflection glint */}
            <motion.span
              initial={{ x: "-150%" }}
              animate={{ x: "250%" }}
              transition={{
                repeat: Infinity,
                repeatType: "loop",
                duration: 2.8,
                repeatDelay: 1.2,
                ease: "easeInOut",
              }}
              className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-20 pointer-events-none z-10"
            />
          </button>
        </div>

      </div>
    </section>
  );
}
