import { useState, useEffect, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, CheckCircle2, Send, Phone, ArrowRight, MessageSquare, ShieldCheck, FileText } from "lucide-react";
import { OrderFormInputs } from "../types";
import { CONTACT_INFO } from "../data";

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  presetWorkType?: string;
  presetSpecialty?: string;
  hasDiscountApplied?: boolean;
}

export default function OrderModal({
  isOpen,
  onClose,
  presetWorkType = "Практика стандарт",
  presetSpecialty = "",
  hasDiscountApplied = false,
}: OrderModalProps) {
  const [formData, setFormData] = useState<OrderFormInputs>({
    name: "",
    phone: "",
    telegram: "",
    specialty: presetSpecialty,
    workType: presetWorkType,
    hasDiscount: hasDiscountApplied,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Sync state if props change when reopened
  useEffect(() => {
    if (isOpen) {
      setFormData({
        name: "",
        phone: "",
        telegram: "",
        specialty: presetSpecialty,
        workType: presetWorkType,
        hasDiscount: hasDiscountApplied,
      });
      setErrors({});
      setIsSuccess(false);
      setIsSubmitting(false);
    }
  }, [isOpen, presetWorkType, presetSpecialty, hasDiscountApplied]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = "Пожалуйста, введите ваше имя";
    if (!formData.phone.trim()) {
      newErrors.phone = "Пожалуйста, введите номер телефона";
    } else if (formData.phone.replace(/\D/g, "").length < 10) {
      newErrors.phone = "Неверный формат номера";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1000);
  };

  // Dynamic price estimator (mocked for better interactivity)
  const getEstimatedPrice = () => {
    let basePrice = 1500;
    if (formData.workType === "Практика Express") basePrice = 3000;
    if (formData.workType === "Кейс-задачи и презентация") basePrice = 1000;
    if (formData.workType === "Курсовая работа") basePrice = 2500;
    if (formData.workType === "Дипломная работа") basePrice = 8000;
    if (formData.workType === "Отчеты по заданию") basePrice = 1800;

    if (formData.hasDiscount) {
      return {
        original: basePrice,
        discounted: Math.round(basePrice * 0.85),
        discountPercent: "15%",
      };
    }
    return { original: basePrice, discounted: basePrice };
  };

  const pricing = getEstimatedPrice();

  return (
    <div id="modal-container" className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        id="modal-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs"
      />

      {/* Modal Card */}
      <motion.div
        id="modal-card"
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl"
      >
        {/* Header decoration */}
        <div className="bg-sky-500 px-6 py-4 text-white">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Оформление заявки
            </h3>
            <button
              onClick={onClose}
              className="rounded-full p-1 text-white/85 hover:bg-white/10 hover:text-white transition-colors"
              aria-label="Закрыть"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <p className="mt-1 text-xs text-sky-100">
            Оставьте свои контакты, специалист свяжется в течение 15 минут
          </p>
        </div>

        {/* Content */}
        <div className="p-6">
          <AnimatePresence mode="wait">
            {!isSuccess ? (
              <motion.form
                id="order-form-fields"
                key="form"
                onSubmit={handleSubmit}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                {/* Work Type Selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Вид работы
                  </label>
                  <select
                    value={formData.workType}
                    onChange={(e) => setFormData({ ...formData, workType: e.target.value })}
                    className="w-full text-sm font-medium rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-slate-900 focus:border-sky-500 focus:bg-white focus:outline-hidden transition-all"
                  >
                    <option value="Практика стандарт">Практика стандарт (до 3 дней)</option>
                    <option value="Практика Express">Практика Express (за 2-3 часа)</option>
                    <option value="Кейс-задачи и презентация">Кейс-задачи и презентация</option>
                    <option value="Курсовая работа">Курсовая работа (договорная)</option>
                    <option value="Дипломная работа">Дипломная работа (договорная)</option>
                    <option value="Отчеты по заданию">Отчеты по заданию</option>
                  </select>
                </div>

                {/* Specialty */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Специальность / Направление
                  </label>
                  <input
                    type="text"
                    placeholder="Например: Бухгалтерский учет, Программирование"
                    value={formData.specialty || ""}
                    onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
                    className="w-full text-sm rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-slate-900 focus:border-sky-500 focus:bg-white focus:outline-hidden transition-all"
                  />
                </div>

                {/* Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Ваше имя <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Иван Иванов"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className={`w-full text-sm rounded-lg border px-3 py-2 text-slate-900 focus:bg-white focus:outline-hidden transition-all ${
                      errors.name ? "border-rose-300 bg-rose-50 focus:border-rose-500" : "border-slate-200 bg-slate-50 focus:border-sky-500"
                    }`}
                  />
                  {errors.name && <p className="mt-1 text-xs text-rose-500">{errors.name}</p>}
                </div>

                {/* Phone & Telegram */}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Телефон <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="tel"
                      placeholder="+7 (___) ___-__-__"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`w-full text-sm rounded-lg border px-3 py-2 text-slate-900 focus:bg-white focus:outline-hidden transition-all ${
                        errors.phone ? "border-rose-300 bg-rose-50 focus:border-rose-500" : "border-slate-200 bg-slate-50 focus:border-sky-500"
                      }`}
                    />
                    {errors.phone && <p className="mt-1 text-xs text-rose-500">{errors.phone}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Telegram логин / Никнейм
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400">@</span>
                      <input
                        type="text"
                        placeholder="telegram_username"
                        value={formData.telegram || ""}
                        onChange={(e) => setFormData({ ...formData, telegram: e.target.value })}
                        className="w-full text-sm rounded-lg border border-slate-200 bg-slate-50 py-2 pl-7 pr-3 text-slate-900 focus:border-sky-500 focus:bg-white focus:outline-hidden transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Live Estimator Indicator */}
                <div className="rounded-xl bg-sky-50/70 p-4 border border-sky-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-600 block">Оценочная стоимость:</span>
                    <span className="text-lg font-bold text-slate-900">
                      {pricing.discounted === pricing.original ? (
                        <> {pricing.original > 8000 ? "Договорная" : pricing.original + " ₽"} </>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className="text-base text-slate-900 font-bold">{pricing.discounted} ₽</span>
                          <span className="text-xs text-slate-400 line-through font-normal">{pricing.original} ₽</span>
                        </div>
                      )}
                    </span>
                  </div>
                  {formData.hasDiscount && (
                    <span className="text-xs bg-emerald-500 text-white font-semibold px-2 py-1 rounded-sm">
                      Скидка 15% у вас активна!
                    </span>
                  )}
                </div>

                {/* Guarantees */}
                <div className="flex items-start gap-2.5 text-xs text-slate-500">
                  <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span>
                    Нажимая кнопку, вы соглашаетесь на обработку персональных данных. Мы гарантируем 100% конфиденциальность. Работа будет выполнена с подписями и печатью.
                  </span>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="relative overflow-hidden group/btn w-full flex items-center justify-center gap-2 rounded-xl bg-sky-500 hover:bg-sky-600 active:bg-sky-700 text-white py-3.5 font-bold uppercase tracking-wider text-xs cursor-pointer shadow-md transition-all disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin relative z-10" />
                      <span className="relative z-10">Отправка данных...</span>
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 relative z-10" />
                      <span className="relative z-10">Отправить заявку специалисту</span>

                      {/* Shimmer reflection glint */}
                      <motion.span
                        initial={{ x: "-150%" }}
                        animate={{ x: "250%" }}
                        transition={{
                          repeat: Infinity,
                          repeatType: "loop",
                          duration: 2.8,
                          repeatDelay: 1.5,
                          ease: "easeInOut",
                        }}
                        className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-20 pointer-events-none z-10"
                      />
                    </>
                  )}
                </button>
              </motion.form>
            ) : (
              <motion.div
                id="order-success-stage"
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-6 text-center space-y-5"
              >
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                  <CheckCircle2 className="h-8 w-8" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-xl font-bold text-slate-900">Заявка успешно отправлена!</h4>
                  <p className="text-sm text-slate-600 max-w-sm mx-auto">
                    Спасибо, <b className="text-slate-900">{formData.name}</b>! Ваша заявка на тему <b>«{formData.workType}»</b> принята в работу. Специалист ответит в Telegram или наберет вас по телефону в течение 10-15 минут.
                  </p>
                </div>

                <div className="rounded-xl bg-slate-50 p-4 border border-slate-100 max-w-sm mx-auto text-left space-y-3">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-widest block text-center">
                    Для ускорения связи:
                  </span>
                  <div className="grid grid-cols-2 gap-3">
                    <a
                      href={CONTACT_INFO.telegram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 rounded-lg bg-sky-500 text-white py-2 px-3 text-xs font-semibold hover:bg-sky-600 transition-colors"
                    >
                      <MessageSquare className="h-3.5 w-3.5" />
                      В Telegram-бот
                    </a>
                    <a
                      href={`https://vk.com`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 rounded-lg bg-blue-600 text-white py-2 px-3 text-xs font-semibold hover:bg-blue-700 transition-colors"
                    >
                      <Phone className="h-3.5 w-3.5" />
                      Группа ВКонтакте
                    </a>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onClose}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-sky-500 hover:text-sky-600 transition-colors cursor-pointer"
                >
                  Вернуться на сайт
                  <ArrowRight className="h-4 w-4" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
