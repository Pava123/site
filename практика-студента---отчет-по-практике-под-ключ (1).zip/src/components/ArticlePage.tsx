import { useState, useEffect } from "react";
import { ArrowLeft, CheckCircle, FileText, PhoneCall, GraduationCap, ShieldCheck, Calendar, BookOpen, ArrowRight, BookMarked, Tags, FileCheck } from "lucide-react";
import { CONTACT_INFO, NAV_DROPDOWN_DATA } from "../data";
import { EXTRACTED_ARTICLES, ExtractedArticle } from "../extractedArticles";

interface ArticlePageProps {
  currentHash: string;
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
  onNavigateHome: () => void;
}

export default function ArticlePage({ currentHash, onOpenOrder, onNavigateHome }: ArticlePageProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;

  // Clean the path from the hash
  const pathClean = currentHash.replace("#", "");

  // Reset page when hash changes
  useEffect(() => {
    setCurrentPage(1);
    const container = document.getElementById("article-view-root");
    if (container) {
      container.scrollIntoView({ behavior: "smooth" });
    }
  }, [currentHash]);

  // Find matches in EXTRACTED_ARTICLES
  let matchedExtracted = EXTRACTED_ARTICLES.find(
    (a) => a.url === pathClean || a.url === pathClean + "/" || `${a.url}/` === pathClean || a.url.replace(/\/$/, "") === pathClean.replace(/\/$/, "")
  );

  const vuzSuffixes = [
    { id: "mti", name: "МТИ", fullName: "Московский технологический институт (МТИ)" },
    { id: "synergy", name: "Синергия", fullName: "Университет «Синергия»" },
    { id: "mosap", name: "МОСАП", fullName: "Московская открытая социальная академия" },
    { id: "witte", name: "С.Ю.Витте", fullName: "Московский университет им. С.Ю. Витте" },
  ];

  // If no exact match, but it's one of our dynamic university practice pages
  if (!matchedExtracted) {
    const matchedSuffix = vuzSuffixes.find(s => 
      pathClean.toLowerCase().includes(`-${s.id}`)
    );
    let baseTypeKey = "";
    if (pathClean.toLowerCase().includes("uchebno-oznakomitelnaya")) baseTypeKey = "uchebno-oznakomitelnaya";
    else if (pathClean.toLowerCase().includes("uchebnaya")) baseTypeKey = "uchebnaya";
    else if (pathClean.toLowerCase().includes("proizvodstvennaya")) baseTypeKey = "proizvodstvennaya";
    else if (pathClean.toLowerCase().includes("preddiplomnaya")) baseTypeKey = "preddiplomnaya";

    if (matchedSuffix && baseTypeKey) {
      const baseArticleUrl = `/otchyot-po-praktike/${baseTypeKey}/`;
      const baseArticle = EXTRACTED_ARTICLES.find(a => a.url === baseArticleUrl || a.url === baseArticleUrl.replace(/\/$/, ""));
      
      if (baseArticle) {
        // Clone and customize!
        const vuzName = matchedSuffix.name;
        const vuzFullName = matchedSuffix.fullName;
        
        // Determine type string
        let typeString = "отчета по практике";
        if (baseTypeKey === "uchebno-oznakomitelnaya") typeString = "учебно-ознакомительной практики";
        else if (baseTypeKey === "uchebnaya") typeString = "учебной практики";
        else if (baseTypeKey === "proizvodstvennaya") typeString = "производственной практики";
        else if (baseTypeKey === "preddiplomnaya") typeString = "preddiplomnoy"; // keep grammar pretty
        
        let typeStringReadable = "";
        if (baseTypeKey === "uchebno-oznakomitelnaya") typeStringReadable = "учебно-ознакомительной практики";
        else if (baseTypeKey === "uchebnaya") typeStringReadable = "учебной практики";
        else if (baseTypeKey === "proizvodstvennaya") typeStringReadable = "производственной практики";
        else if (baseTypeKey === "preddiplomnaya") typeStringReadable = "преддипломной практики";

        matchedExtracted = {
          url: pathClean,
          category: "Отчёты по практике",
          h1: `Отчёт по ${typeStringReadable} в ${vuzName} в 2026 году`,
          publishDate: "2026-05-20",
          keywords: [vuzName, "практика", typeStringReadable.split(" ")[0], "отчет"],
          summary: `Профессиональное руководство по самостоятельному написанию и успешному оформлению отчёта по ${typeStringReadable} для студентов ${vuzFullName} в соответствии с ГОСТом и методическими указаниями.`,
          contentStructure: baseArticle.contentStructure.map(section => {
            let updatedBody = section.body
              .replace(/вашего вуза/gi, `${vuzName}`)
              .replace(/ВУЗе/g, `${vuzName}`)
              .replace(/принявшего предприятия/gi, `принимающего предприятия по регламенту ${vuzName}`);
            
            if (section === baseArticle.contentStructure[0]) {
              updatedBody = `Специфика выполнения отчета для ${vuzFullName} (${vuzName}) требует строгого следования внутренним методическим указаниям, включая заполнение дневника и получение характеристики от руководителя с печатью.\n\n` + updatedBody;
            }

            return {
              title: section.title.replace(/вуза/gi, vuzName),
              level: section.level,
              body: updatedBody
            };
          })
        };
      }
    }
  }

  // Fallback category detection
  const isCategoryRoot = ["/otchety-po-praktike", "/useful-articles", "/other-works"].includes(pathClean);

  // Find current item metadata inside menu tree (for tags or titles)
  let menuNode: { name: string; path: string; type?: string } | null = null;
  let tabTitle = "";

  for (const cat of NAV_DROPDOWN_DATA) {
    const item = cat.items.find((i) => i.path === pathClean || i.path.replace(/\/$/, "") === pathClean.replace(/\/$/, ""));
    if (item) {
      menuNode = item;
      tabTitle = cat.tabTitle;
      break;
    }
  }

  if (!tabTitle && pathClean.includes("otchyot-po-praktike")) {
    tabTitle = "Виды практик";
  }

  // Calculate variables
  const pageTitle = matchedExtracted 
    ? matchedExtracted.h1 
    : (menuNode ? menuNode.name : (isCategoryRoot ? "Раздел публикаций" : "Ресурс для студентов"));

  const publishDate = matchedExtracted?.publishDate || "2026-05-15";
  const summary = matchedExtracted?.summary || "Официальные требования методических указаний вашего вуза. Материалы подготовлены квалифицированными преподавателями и сертифицированными экспертами.";
  const kws = matchedExtracted?.keywords || ["учеба", "практика", "отчетность", "гост", "студенты"];

  // Dynamic related item listings for categories (to implement real pagination)
  let activeCategoryArticles: ExtractedArticle[] = [];
  if (pathClean.includes("otchyot-po-praktike") || pathClean.includes("otchety-po-praktike")) {
    activeCategoryArticles = EXTRACTED_ARTICLES.filter(a => a.category === "Отчёты по практике");
  } else if (pathClean.includes("rating") || pathClean.includes("useful-articles") || pathClean.includes("nir")) {
    activeCategoryArticles = EXTRACTED_ARTICLES.filter(a => a.category === "ПОЛЕЗНЫЕ СТАТЬИ");
  } else {
    activeCategoryArticles = EXTRACTED_ARTICLES.filter(a => a.category === "ДРУГИЕ ВИДЫ РАБОТ");
  }

  // Slicing articles for pagination
  const totalPages = Math.ceil(activeCategoryArticles.length / itemsPerPage);
  const paginatedArticles = activeCategoryArticles.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleOrderClick = () => {
    onOpenOrder(pageTitle, "", false);
  };

  return (
    <div id="article-view-root" className="bg-[#FAF9F6] min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-6xl">
        
        {/* Breadcrumb line navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <button
            onClick={onNavigateHome}
            className="flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-xs font-bold text-slate-705 text-slate-700 shadow-sm border border-slate-200 hover:text-[#2563EB] hover:border-blue-300 transition-all cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            Вернуться на главную
          </button>

          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-bold uppercase tracking-wider">
            <span className="hover:text-slate-650 cursor-pointer" onClick={onNavigateHome}>Главная</span>
            <span>/</span>
            {tabTitle && <span className="text-slate-500">{tabTitle}</span>}
            {tabTitle && <span>/</span>}
            <span className="text-slate-905 text-slate-900 font-extrabold truncate max-w-[250px]">{pageTitle}</span>
          </div>
        </div>

        {/* Large Aesthetic Article Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-slate-950 text-white p-8 sm:p-12 shadow-xl border border-slate-900 mb-8">
          <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none select-none">
            <GraduationCap className="h-60 w-60" />
          </div>
          
          <div className="relative z-10 space-y-4 max-w-4xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-[10px] bg-sky-500/20 text-sky-300 font-black px-3 py-1.5 rounded-md border border-sky-500/30 uppercase tracking-widest">
                {matchedExtracted?.category || tabTitle || "БАЗА ЗНАНИЙ СТУДЕНТА"}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] text-slate-400 font-semibold bg-slate-900 px-2.5 py-1.5 rounded-md">
                <Calendar className="h-3 w-3" />
                {publishDate}
              </span>
            </div>
            
            <h1 className="text-xl sm:text-3.5xl font-black text-white leading-tight">
              {pageTitle}
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
              {summary}
            </p>

            {/* Keyword pills from the crawling meta info */}
            <div className="flex flex-wrap gap-2 pt-2">
              {kws.map((kw, idx) => (
                <span key={idx} className="text-[10px] bg-slate-900 text-slate-400 font-bold py-1 px-2.5 rounded-md border border-slate-800">
                  #{kw}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Core Layout split: main text vs side info */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Article Content */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* 1. Dynamic body from crawling database */}
            {matchedExtracted && matchedExtracted.contentStructure && matchedExtracted.contentStructure.length > 0 ? (
              <div className="rounded-2xl bg-white p-6 sm:p-8 shadow-xs border border-slate-200/60 space-y-6">
                <h2 className="text-lg font-black text-slate-950 flex items-center gap-2 border-b border-slate-100 pb-3 uppercase tracking-tight">
                  <BookMarked className="h-5.5 w-5.5 text-sky-500" />
                  Полный текст инструкции
                </h2>

                {matchedExtracted.contentStructure.map((section, idx) => (
                  <div key={idx} className="space-y-3">
                    {section.level === 2 ? (
                      <h3 className="text-base font-extrabold text-slate-900 pt-2 flex items-center gap-2 border-l-4 border-sky-500 pl-3">
                        {section.title}
                      </h3>
                    ) : (
                      <h4 className="text-sm font-bold text-slate-800 pt-1">
                        {section.title}
                      </h4>
                    )}
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                      {section.body}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              // General Category fallback page
              <div className="rounded-2xl bg-white p-6 sm:p-8 shadow-xs border border-slate-200/60 space-y-4">
                <h2 className="text-lg font-black text-slate-950 flex items-center gap-2 border-b border-slate-100 pb-3 uppercase">
                  <GraduationCap className="h-5.5 w-5.5 text-sky-500" />
                  Добро пожаловать в раздел
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Выберите конкретную подтему из выпадающего меню сверху или воспользуйтесь каталогом карточек ниже с постраничной навигацией для детального ознакомления с материалами методических рекомендаций ГОСТ 2026 года.
                </p>
              </div>
            )}

            {/* 2. Standard blueprint structure */}
            <div className="rounded-2xl bg-white p-6 sm:p-8 shadow-xs border border-slate-200/60 space-y-4">
              <h2 className="text-lg font-black text-slate-950 flex items-center gap-2 border-b border-slate-100 pb-3 uppercase tracking-tight">
                <FileCheck className="h-5.5 w-5.5 text-sky-500" />
                Параметры и состав документов по ГОСТу
              </h2>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-[#FAF9F6] text-slate-500 font-bold uppercase tracking-wider">
                      <th className="p-3">Раздел проекта</th>
                      <th className="p-3">Объем</th>
                      <th className="p-3">Основные нормативы</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-semibold text-slate-600">
                    <tr>
                      <td className="p-3 font-extrabold text-[#2563EB]">Введение и актуальность</td>
                      <td className="p-3">2-3 стр.</td>
                      <td className="p-3">Формулируются задачи, научный объект исследования и личный план студента.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-extrabold text-[#2563EB]">Организационный профиль</td>
                      <td className="p-3">5-8 стр.</td>
                      <td className="p-3">Полная правовая и финансовая структура принимающего предприятия с ОГРН.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-extrabold text-[#2563EB]">Расчетный аналитический раздел</td>
                      <td className="p-3">12-18 стр.</td>
                      <td className="p-3">Сводный баланс деятельности, формулы, исходные данные и выявление дефектов.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-extrabold text-[#2563EB]">Заключение и выводы</td>
                      <td className="p-3">2-3 стр.</td>
                      <td className="p-3">Результаты индивидуального вклада и рекомендации куратору с базы практики.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pagination & List block: 'и обрати внимание чтов конце ссылок могут быть следующие старницы сделай так же на нашем сайте' */}
            {activeCategoryArticles.length > 0 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="text-md sm:text-lg font-black text-slate-900 uppercase">
                    Материалы раздела ({activeCategoryArticles.length})
                  </h3>
                  <span className="text-xs text-slate-400 font-bold">
                    Постраничная навигация по сайту-донору:
                  </span>
                </div>

                {/* Grid of articles for current page */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {paginatedArticles.map((art) => {
                    const isActive = art.url === pathClean;
                    return (
                      <div
                        key={art.url}
                        className={`p-5 rounded-2xl border transition-all duration-300 flex flex-col justify-between ${
                          isActive
                            ? "bg-blue-50/50 border-blue-300 shadow-sm"
                            : "bg-white border-slate-200/80 hover:border-blue-300 hover:shadow-md"
                        }`}
                      >
                        <div className="space-y-2">
                          <span className="text-[9px] bg-slate-100 font-extrabold text-slate-500 py-1 px-2.5 rounded-md uppercase tracking-wide">
                            {art.category}
                          </span>
                          <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 group-hover:text-sky-500 leading-snug">
                            {art.h1}
                          </h4>
                          <p className="text-[11px] text-slate-400 font-medium leading-relaxed line-clamp-2">
                            {art.summary}
                          </p>
                        </div>

                        <div className="pt-4 border-t border-slate-100 flex items-center justify-between mt-4">
                          <span className="text-[10px] text-slate-400 font-semibold flex items-center gap-1">
                            <Calendar className="h-3 w-3" /> {art.publishDate}
                          </span>
                          <a
                            href={`#${art.url}`}
                            className={`flex items-center gap-1 text-[11px] font-bold ${
                              isActive ? "text-[#2563EB]" : "text-sky-500 hover:text-sky-600"
                            }`}
                          >
                            <span>{isActive ? "Читаете сейчас" : "Читать"}</span>
                            <ArrowRight className="h-3 w-3" />
                          </a>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Paginated Navigation buttons */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 pt-2">
                    <button
                      disabled={currentPage === 1}
                      onClick={() => {
                        setCurrentPage(currentPage - 1);
                        document.getElementById("useful-sub-list-title")?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:border-blue-300 hover:text-[#2563EB] disabled:opacity-50 disabled:hover:text-slate-600 disabled:hover:border-slate-200 transition-all cursor-pointer"
                    >
                      &larr; Назад
                    </button>
                    
                    {[...Array(totalPages)].map((_, i) => {
                      const pNum = i + 1;
                      const isCurrent = pNum === currentPage;
                      return (
                        <button
                          key={pNum}
                          onClick={() => {
                            setCurrentPage(pNum);
                            document.getElementById("useful-sub-list-title")?.scrollIntoView({ behavior: 'smooth' });
                          }}
                          className={`w-9 h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            isCurrent
                              ? "bg-[#2563EB] text-white shadow-md border-transparent"
                              : "bg-white border border-slate-200 text-slate-650 text-slate-700 hover:border-blue-300"
                          }`}
                        >
                          {pNum}
                        </button>
                      );
                    })}

                    <button
                      disabled={currentPage === totalPages}
                      onClick={() => {
                        setCurrentPage(currentPage + 1);
                        document.getElementById("useful-sub-list-title")?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:border-blue-300 hover:text-[#2563EB] disabled:opacity-50 disabled:hover:text-slate-600 disabled:hover:border-slate-200 transition-all cursor-pointer"
                    >
                      Вперед &rarr;
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>

          {/* Dynamic Sidebar with order button & guarantees */}
          <div className="space-y-6">
            
            {/* Quick pricing & CTA order card */}
            <div className="rounded-2xl bg-white p-6 shadow-xs border border-slate-200/60 text-center space-y-4">
              <span className="inline-flex items-center gap-1.5 text-[9px] bg-emerald-100 text-emerald-800 font-black px-3 py-1 rounded-full uppercase tracking-wider">
                ГАРАНТИЯ СДАЧИ 100%
              </span>
              
              <div className="space-y-1">
                <span className="text-[11px] text-slate-400 font-bold block uppercase tracking-wide">Разработка по теме:</span>
                <span className="text-2.5xl sm:text-3xl font-black text-slate-900 block font-mono">от 2 500 ₽</span>
                <span className="text-xs text-sky-550 text-sky-500 font-bold block flex items-center justify-center gap-1">
                  <Calendar className="h-3 w-3" /> Сроки: от 1 до 3 дней
                </span>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-3">
                <button
                  onClick={handleOrderClick}
                  className="w-full rounded-xl bg-sky-505 bg-sky-500 hover:bg-sky-600 text-white font-extrabold py-3.5 text-xs uppercase tracking-wider cursor-pointer shadow-md shadow-sky-500/10 active:scale-98 transition-all"
                >
                  Заказать расчет по теме &rarr;
                </button>
                
                <span className="text-[10px] text-slate-400 block font-semibold leading-relaxed">
                  Бесплатные правки, подписи, мокрые синие печати и техническое сопровождение до самой защиты включены в цену!
                </span>
              </div>
            </div>

            {/* Quick Consultation Messengers block */}
            <div className="rounded-2xl bg-slate-900 p-6 text-white text-center space-y-5">
              <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-sky-500 text-white shadow-md">
                <PhoneCall className="h-5 w-5" />
              </div>

              <div className="space-y-1">
                <h3 className="text-sm sm:text-base font-black uppercase tracking-tight">Нужен срочный расчет?</h3>
                <p className="text-[11px] text-slate-400 font-semibold leading-relaxed">Отправьте методичку куратору. Расчет стоимости займет менее 10 минут!</p>
              </div>

              <div className="space-y-2.5">
                <a
                  href={CONTACT_INFO.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] text-white py-2.5 text-xs font-bold uppercase hover:opacity-90 transition-all shadow-sm"
                >
                  Написать в WhatsApp
                </a>
                <a
                  href={CONTACT_INFO.telegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 rounded-xl bg-[#0088cc] text-white py-2.5 text-xs font-bold uppercase hover:opacity-90 transition-all shadow-sm"
                >
                  Написать в Telegram
                </a>
              </div>

              <div className="border-t border-slate-800 pt-4 text-[11px] space-y-2 font-semibold">
                <a
                  href={`tel:${CONTACT_INFO.primaryPhoneLink}`}
                  className="block font-black text-white text-sm hover:text-sky-305 transition-all"
                >
                  Тел: {CONTACT_INFO.primaryPhone}
                </a>
                <a
                  href={`mailto:${CONTACT_INFO.email}`}
                  className="block font-bold text-slate-400 hover:text-sky-305 transition-all"
                >
                  {CONTACT_INFO.email}
                </a>
              </div>
            </div>

            {/* Guarantees badges block */}
            <div className="rounded-2xl bg-white p-5 shadow-xs border border-slate-200/60 space-y-3.5 text-left">
              <span className="text-xs uppercase font-black text-slate-900 block border-b border-slate-100 pb-2 flex items-center gap-1.5">
                <ShieldCheck className="h-4.5 w-4.5 text-sky-500" />
                Гарантии центра «Доннор»
              </span>

              <div className="space-y-3 text-xs text-slate-600 font-medium">
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="h-4 w-4 text-emerald-555 text-emerald-500 shrink-0 mt-0.5" />
                  <span>Работаем официально, заключаем надежный двусторонний договор.</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="h-4 w-4 text-emerald-555 text-emerald-500 shrink-0 mt-0.5" />
                  <span>Бесплатное сопровождение правок научного руководителя до защиты.</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="h-4 w-4 text-emerald-555 text-emerald-500 shrink-0 mt-0.5" />
                  <span>Все печати реальных действующих организаций России (ЕГРЮЛ).</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
