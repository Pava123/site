import { Mail, Phone, ArrowRight, MessageSquare, Percent } from "lucide-react";
import { CONTACT_INFO } from "../data";
import { motion } from "motion/react";

interface HowItWorksProps {
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
}

export default function HowItWorks({ onOpenOrder }: HowItWorksProps) {
  const steps = [
    {
      num: "1",
      title: "Заявка на сайте",
      desc: (
        <>
          <b className="text-slate-950 font-extrabold uppercase text-xs block mb-1">Вы:</b>
          Оставляете быструю заявку на сайте.
          <b className="text-slate-950 font-extrabold uppercase text-xs block mt-2 mb-1">Мы:</b>
          Связываемся с вами в течение <span className="bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-sm font-bold">15-30 минут</span> для подробного уточнения данных.
        </>
      ),
    },
    {
      num: "2",
      title: "Оформление пакета",
      desc: (
        <>
          <b className="text-slate-950 font-extrabold uppercase text-xs block mb-1">Для оформления вы:</b>
          Пересылаете нам пустые шаблоны документов или методички кафедры.
          <b className="text-slate-950 font-extrabold uppercase text-xs block mt-2 mb-1">После чего мы:</b>
          Обговариваем индивидуальные условия прохождения практики.
        </>
      ),
    },
    {
      num: "3",
      title: "Сборка документов",
      desc: (
        <>
          <b className="text-slate-950 font-extrabold uppercase text-xs block mb-1">По завершению мы:</b>
          В течение <span className="bg-sky-100 text-sky-800 px-1.5 py-0.5 rounded-sm font-bold">1-3 дней</span> собираем весь пакет документов, пишем отчет и высылаем на вашу проверку.
        </>
      ),
    },
    {
      num: "4",
      title: "Проверка документов",
      desc: (
        <>
          <b className="text-slate-950 font-extrabold uppercase text-xs block mb-1">Вы:</b>
          Проверяете правильность заполнения бланков.
          <b className="text-sky-500 font-extrabold uppercase text-xs block mt-2 mb-1 animate-pulse">Итог:</b>
          Получаете готовую практику с оригинальной печатью и подписью на почте.
        </>
      ),
    },
  ];

  return (
    <section id="how-to" className="relative z-10 bg-white py-20 sm:py-24 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header Titles */}
        <div className="text-center space-y-3 mb-12 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-sky-500 bg-sky-500/10 px-3 py-1 rounded-sm">
            Вам нужна практика для получения зачета, диплома, закрытия сессии!
          </span>
          <h2 className="text-2.5xl sm:text-4xl font-sans font-black tracking-tight text-slate-900 uppercase">
            КАК ПРОЙТИ ПРАКТИКУ?
          </h2>
          <p className="text-sm font-medium text-slate-500 max-w-lg mx-auto">
            Максимально простая и прозрачная схема работы без лишней бюрократии
          </p>
        </div>

        {/* 4 Steps Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {steps.map((step) => (
            <div
              key={step.num}
              className="relative flex flex-col justify-between rounded-2xl border border-slate-100 bg-slate-55/40 p-5 shadow-xs bg-slate-50/50"
            >
              <div className="space-y-4">
                {/* Visual Number circle badge */}
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-sky-500 text-sm font-black text-white">
                  {step.num}
                </div>

                <div className="space-y-1.5">
                  <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide">
                    {step.title}
                  </h3>
                  <div className="text-slate-600 text-xs sm:text-sm leading-relaxed">
                    {step.desc}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Under-steps horizontal CTA box */}
        <div className="mt-12 rounded-2xl bg-sky-50 p-6 border border-sky-100 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
            <button
              onClick={() => onOpenOrder("Заявка со скидкой 15%", "", true)}
              className="relative overflow-hidden group w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold px-6 py-3.5 text-xs uppercase tracking-wider cursor-pointer shadow-md transition-all active:scale-98"
            >
              <Percent className="h-4 w-4 relative z-10" />
              <span className="relative z-10">Получить скидку на 1-й заказ</span>

              {/* Shimmer reflection glint */}
              <motion.span
                initial={{ x: "-150%" }}
                animate={{ x: "250%" }}
                transition={{
                  repeat: Infinity,
                  repeatType: "loop",
                  duration: 2.8,
                  repeatDelay: 1.8,
                  ease: "easeInOut",
                }}
                className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-20 pointer-events-none z-10"
              />
            </button>
            <span className="text-slate-400 font-semibold text-xs sm:text-sm text-center sm:text-left">или напишите в удобный мессенджер:</span>
          </div>

          {/* Messenger Circle Icons */}
          <div className="flex items-center gap-3">
            <a
              href={CONTACT_INFO.telegram}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-sky-400 hover:bg-sky-500 text-white hover:scale-110 shadow-xs transition-all"
              title="Написать в Telegram"
            >
              <MessageSquare className="h-5 w-5 fill-white text-sky-400" />
            </a>
            <a
              href="https://vk.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-blue-600 hover:bg-blue-700 text-white hover:scale-110 shadow-xs transition-all"
              title="Группа ВКонтакте"
            >
              <Phone className="h-5 w-5" />
            </a>
            <a
              href={CONTACT_INFO.viber}
              className="flex h-11 w-11 items-center justify-center rounded-full bg-indigo-505 bg-violet-600 hover:bg-violet-700 text-white hover:scale-110 shadow-xs transition-all"
              title="Написать в Viber"
            >
              <Mail className="h-5 w-5" />
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}
