import React, { useState } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

export default function FAQList() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqData: FAQItem[] = [
    {
      question: "Какая организация будет указана в моих документах базы практики?",
      answer: "Мы подбираем только реально действующие предприятия и ООО из официального реестра ФНС РФ, профиль деятельности которых строго соответствует вашей специальности обучения. Например, для будущих юристов — это юридические консультации, правовые центры или коллегии адвокатов; для экономистов и менеджеров — торговые, сервисные и производственные компании любого масштаба; для ИТ-специалистов — стабильные ИТ-интеграторы, ИТ-отделы крупных компаний или веб-студии."
    },
    {
      question: "Подтверждает ли компания прохождение практики в случае звонка из вуза?",
      answer: "Да, обязательно. Все базы практик, с которыми мы имеем партнерские соглашения, осведомлены о сотрудничестве. В случае официального звонка из деканата вуза, куратора или комиссии по защите, уполномоченные представители компании подтвердят, что вы благополучно прошли у них практику в указанные сроки, ознакомились с рабочими процессами и образцово выполняли возложенные обязанности согласно индивидуальному плану."
    },
    {
      question: "В какие сроки изготавливается полный комплект документов по практике?",
      answer: "Стандартное написание полноценного отчета и подготовка сопутствующих документов (договор, дневник, характеристика) занимает от 2 до 3 рабочих дней. Если у вас возникла срочная ситуация и сессия сдается прямо сейчас, вы можете воспользоваться экспресс-тарифом: в таком случае полный комплект документов с мокрыми печатями в виде качественных сканов в PDF будет выслан вам на электронную почту в течение 2-3 часов с момента заказа."
    },
    {
      question: "Что делать, если мой научный руководитель потребует внести исправления в отчет?",
      answer: "Такие ситуации случаются, когда научный руководитель хочет увидеть в отчете определенные главы или изменить оформление по новому регламенту. Вам достаточно отправить нам текстовый список замечания вашего преподавателя или скриншот. Мы оперативно внесем абсолютно все необходимые корректировки полностью бесплатно в рамках вашего заказа. Гарантия бесплатных правок действует до момента вашей окончательной успешной сдачи и защиты."
    },
    {
      question: "Какая уникальность текста будет в моем отчете по практике?",
      answer: "Мы гарантируем прохождение контроля в системе Антиплагиат.ВУЗ на высоком уровне — стандартно от 70-75% оригинальности и выше в зависимости от ваших методических рекомендаций. Весь аналитический текст, финансовые выводы, таблицы, расчетные формулы и графики пишутся индивидуально под вашу компанию живыми авторами, без использования автогенерации, синонимайзеров или нейросетей."
    },
    {
      question: "Вы высылаете оригиналы документов ко мне в город?",
      answer: "Да, конечно. Мы высылаем бумажные оригиналы с оригинальными синими печатями куратора компании-базы и подписями через проверенные службы экспресс-доставки СДЭК прямо к вам в руки или на пункт выдачи, а также заказным письмом Почтой России. Ссылку для отслеживания посылки (трек-номер) мы предоставляем сразу после отправки. Скан-копии документов в высоком разрешении отправляются на почту мгновенно."
    }
  ];

  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="bg-slate-50 py-20 sm:py-24 border-t border-slate-100">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        
        {/* Header content Titles */}
        <div className="text-center space-y-3 mb-12 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-[#2563EB] bg-blue-500/10 px-3 py-1 rounded-sm">
            Ответы на популярные вопросы
          </span>
          <h2 className="text-2.5xl sm:text-4xl font-sans font-black tracking-tight text-slate-900 uppercase">
            Часто задаваемые вопросы
          </h2>
          <p className="text-sm font-medium text-slate-500 max-w-lg mx-auto">
            Собрали полезные ответы, которые чаще всего интересуют студентов перед заказом
          </p>
        </div>

        {/* Decorative Grid items list */}
        <div className="space-y-4">
          {faqData.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all duration-300 overflow-hidden"
              >
                <button
                  onClick={() => handleToggle(idx)}
                  className="w-full flex items-center justify-between p-5 text-left font-extrabold text-[#2d3748] hover:text-slate-950 transition-colors cursor-pointer gap-4 text-sm sm:text-base"
                >
                  <span className="flex items-center gap-2.5">
                    <HelpCircle className="h-5 w-5 text-[#2563EB] shrink-0" />
                    {item.question}
                  </span>
                  <ChevronDown
                    className={`h-5 w-5 text-slate-400 shrink-0 transition-transform duration-300 ${
                      isOpen ? "transform rotate-180 text-[#2563EB]" : ""
                    }`}
                  />
                </button>
                
                {/* Expandable answer panel */}
                <div
                  className={`transition-all duration-300 ease-in-out ${
                    isOpen ? "max-h-[500px] border-t border-slate-100 opacity-100" : "max-h-0 opacity-0 pointer-events-none"
                  } overflow-hidden`}
                >
                  <div className="p-5 text-xs sm:text-sm text-slate-600 leading-relaxed font-normal bg-slate-50">
                    {item.answer}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
