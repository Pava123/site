import { useState, MouseEvent } from "react";
import { Phone, Mail, GraduationCap, ArrowRight, Menu, X, Landmark, ChevronDown } from "lucide-react";
import { CONTACT_INFO, NAV_DROPDOWN_DATA } from "../data";
import Logo from "./Logo";

interface HeaderProps {
  onOpenOrder: (workType?: string, specialty?: string, discount?: boolean) => void;
}

const MAIN_MOBILE_PRACTICES = [
  {
    key: "oznakom",
    name: "Отчёт по ознакомительной практике",
    basePath: "/otchyot-po-praktike/uchebno-oznakomitelnaya/",
    vuzes: [
      { name: "Ознакомительная практика в МТИ", path: "/otchyot-po-praktike/uchebno-oznakomitelnaya-mti" },
      { name: "Ознакомительная практика в Синергии", path: "/otchyot-po-praktike/uchebno-oznakomitelnaya-synergy" },
      { name: "Ознакомительная практика в МОСАП", path: "/otchyot-po-praktike/uchebno-oznakomitelnaya-mosap" },
      { name: "Ознакомительная практика в С.Ю.Витте", path: "/otchyot-po-praktike/uchebno-oznakomitelnaya-witte" },
    ]
  },
  {
    key: "ucheb",
    name: "Отчёт по учебной практике",
    basePath: "/otchyot-po-praktike/uchebnaya/",
    vuzes: [
      { name: "Учебная практика в МТИ", path: "/otchyot-po-praktike/uchebnaya-mti" },
      { name: "Учебная практика в Синергии", path: "/otchyot-po-praktike/uchebnaya-synergy" },
      { name: "Учебная практика в МОСАП", path: "/otchyot-po-praktike/uchebnaya-mosap" },
      { name: "Учебная практика в С.Ю.Витте", path: "/otchyot-po-praktike/uchebnaya-witte" },
    ]
  },
  {
    key: "proizv",
    name: "Отчёт по производственной практике",
    basePath: "/otchyot-po-praktike/proizvodstvennaya/",
    vuzes: [
      { name: "Производственная практика в МТИ", path: "/otchyot-po-praktike/proizvodstvennaya-mti" },
      { name: "Производственная практика в Синергии", path: "/otchyot-po-praktike/proizvodstvennaya-synergy" },
      { name: "Производственная практика в МОСАП", path: "/otchyot-po-praktike/proizvodstvennaya-mosap" },
      { name: "Производственная практика в С.Ю.Витте", path: "/otchyot-po-praktike/proizvodstvennaya-witte" },
    ]
  },
  {
    key: "preddiplom",
    name: "Отчёт по преддипломной практике",
    basePath: "/otchyot-po-praktike/preddiplomnaya/",
    vuzes: [
      { name: "Преддипломная практика в МТИ", path: "/otchyot-po-praktike/preddiplomnaya-mti" },
      { name: "Преддипломная практика в Синергии", path: "/otchyot-po-praktike/preddiplomnaya-synergy" },
      { name: "Преддипломная практика в МОСАП", path: "/otchyot-po-praktike/preddiplomnaya-mosap" },
      { name: "Преддипломная практика в С.Ю.Витте", path: "/otchyot-po-praktike/preddiplomnaya-witte" },
    ]
  }
];

export default function Header({ onOpenOrder }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openMobileCurtains, setOpenMobileCurtains] = useState<Record<string, boolean>>({});
  const [openMobileSubpractices, setOpenMobileSubpractices] = useState<Record<string, boolean>>({});

  const toggleMobileCurtain = (title: string) => {
    setOpenMobileCurtains((prev) => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  const toggleMobileSubpractice = (key: string, e: MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setOpenMobileSubpractices((prev) => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-100 bg-white/95 backdrop-blur-md shadow-xs font-sans">
      
      {/* Top bar with quick contacts */}
      <div className="bg-slate-900 text-slate-400 text-[11px] py-1.5 px-4 sm:px-6 lg:px-8 font-semibold hidden sm:block">
        <div className="mx-auto max-w-7xl flex items-center justify-between">
          <div className="flex items-center gap-5">
            <span className="text-slate-500">Помощь студентам по всей РФ 24/7</span>
            <a
              href={`mailto:${CONTACT_INFO.email}`}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <Mail className="h-3 w-3 text-sky-500" />
              {CONTACT_INFO.email}
            </a>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-slate-400">Срочный расчет за 10 минут</span>
            <a
              href={`tel:${CONTACT_INFO.primaryPhoneLink}`}
              className="flex items-center gap-1 text-white hover:text-sky-400 transition-colors font-bold"
            >
              <Phone className="h-3 w-3 text-sky-500" />
              {CONTACT_INFO.primaryPhone}
            </a>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between gap-4">
          
          {/* Logo */}
          <a href="#" className="flex items-center gap-3.5 group shrink-0" onClick={() => window.location.hash = ""}>
            <Logo />
            <div className="hidden sm:block pl-3 border-l border-slate-200">
              <span className="text-[9px] font-extrabold text-[#2563EB] block tracking-wider uppercase leading-tight">
                Реальные подписи
              </span>
              <span className="text-[9px] font-bold text-slate-500 block tracking-wider uppercase leading-tight">
                и синие печати
              </span>
            </div>
          </a>

          {/* Horizontal Desktop Navigation: Dropdowns on Hover ("Шторки") */}
          <nav className="hidden xl:flex items-center gap-1">
            {NAV_DROPDOWN_DATA.map((curtain) => (
              <div key={curtain.tabTitle} className="relative group py-2 px-3">
                
                {/* Parent Hover Link */}
                <a
                  href={`#${curtain.parentPath}`}
                  className="text-slate-700 group-hover:text-sky-500 font-bold text-xs tracking-wide transition-all uppercase flex items-center gap-1 py-1"
                >
                  {curtain.tabTitle}
                  <ChevronDown className="h-3 w-3 text-slate-400 group-hover:text-sky-500 group-hover:rotate-180 transition-transform duration-300" />
                </a>

                {/* Sub-item drop list (Dropdown) */}
                <ul className="absolute left-0 top-full pt-1 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all duration-200 z-50 w-72">
                  <div className="rounded-2xl border border-slate-100/80 bg-white shadow-xl py-3 overflow-hidden">
                    {/* Header Link for Parent Page */}
                    <li>
                      <a
                        href={`#${curtain.parentPath}`}
                        className="block px-4 py-2 text-[10px] uppercase font-black tracking-wider text-sky-500 bg-sky-50/50 hover:bg-sky-50 transition-all mb-1 border-l-3 border-sky-500"
                      >
                        Обзор раздела &rarr;
                      </a>
                    </li>
                    {curtain.items.map((subItem) => (
                      <li key={subItem.path}>
                        <a
                          href={`#${subItem.path}`}
                          className="block px-4 py-2 hover:bg-slate-50 text-slate-600 hover:text-slate-950 text-xs font-semibold leading-relaxed border-l-3 border-transparent hover:border-sky-500 transition-all"
                        >
                          {subItem.name}
                        </a>
                      </li>
                    ))}
                  </div>
                </ul>

              </div>
            ))}
          </nav>

          {/* Social Icons & Call details (Desktop Layout) */}
          <div className="hidden lg:flex items-center gap-5 shrink-0">
            
            {/* Clickable Social messenger group inside header */}
            <div className="flex items-center gap-2 shrink-0">
              <a
                href={CONTACT_INFO.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                title="Написать в WhatsApp: Здравствуйте! Нужна помощь с отчетом по практике. Перезвоните мне."
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#25D366] text-white hover:scale-105 active:scale-95 transition-all shadow-xs"
              >
                <svg className="h-4.5 w-4.5 fill-current" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.458 5.705 1.459h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </a>
              <a
                href={CONTACT_INFO.telegram}
                target="_blank"
                rel="noopener noreferrer"
                title="Написать в Telegram: Здравствуйте! Нужна помощь с отчетом. Напишите, пожалуйста."
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#0088cc] text-white hover:scale-105 active:scale-95 transition-all shadow-xs"
              >
                <svg className="h-4.5 w-4.5 fill-current" viewBox="0 0 24 24">
                  <path d="M11.944 0a12 12 0 1012 11.944A12 12 0 0011.944 0zm5.556 8.333l-1.91 9a.53.53 0 01-.772.394l-2.92-2.15-1.41 1.36a.375.375 0 01-.624-.183l-.94-3.1-2.73-.85a.372.372 0 01-.013-.7l10.8-4.16a.374.374 0 01.519.389z" />
                </svg>
              </a>
              <a
                href={CONTACT_INFO.max}
                target="_blank"
                rel="noopener noreferrer"
                title="Мы на MAX.ru"
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#8A2BE2] text-white font-black text-sm hover:scale-105 active:scale-95 transition-all shadow-xs"
              >
                М
              </a>
            </div>

            {/* Telephone Call Button */}
            <div className="text-right border-l border-slate-100 pl-4 shrink-0">
              <span className="text-[9px] uppercase font-bold text-slate-400 block tracking-wider whitespace-nowrap">Отдел консультаций:</span>
              <a
                href={`tel:${CONTACT_INFO.primaryPhoneLink}`}
                className="flex items-center justify-end gap-1.5 text-base font-extrabold text-slate-900 hover:text-sky-500 transition-colors whitespace-nowrap"
              >
                <Phone className="h-4 w-4 text-sky-500 animate-pulse shrink-0" />
                {CONTACT_INFO.primaryPhone}
              </a>
            </div>

          </div>

          {/* Mobile Menu Actions */}
          <div className="flex items-center gap-2 xl:hidden shrink-0">
            <button
              onClick={() => onOpenOrder("Заявка с меню", "", false)}
              className="rounded-xl bg-sky-500 hover:bg-sky-600 px-3.5 py-2 text-white transition-all text-xs font-bold shadow-xs cursor-pointer"
            >
              Заказать
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="rounded-xl border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
              aria-label="Переключить меню"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Panel with Accordions for "Шторки" */}
      {mobileMenuOpen && (
        <div className="border-t border-slate-100 bg-white xl:hidden py-4 px-4 space-y-4 shadow-xl max-h-[calc(100vh-80px)] overflow-y-auto">
          
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 px-3 block mb-2">
              Навигация и Виды Практик
            </span>

            {NAV_DROPDOWN_DATA.map((curtain) => {
              const isOpen = !!openMobileCurtains[curtain.tabTitle];
              const isPracticesTab = curtain.tabTitle === "Отчет по практике";
              const displayTabTitle = isPracticesTab ? "Виды практик" : curtain.tabTitle;
              return (
                <div key={curtain.tabTitle} className="border-b border-slate-100 pb-1">
                  <button
                    onClick={() => toggleMobileCurtain(curtain.tabTitle)}
                    className="w-full flex items-center justify-between py-3 px-3 rounded-xl hover:bg-slate-50 text-slate-800 font-bold text-sm text-left transition-colors"
                  >
                    <span>{displayTabTitle}</span>
                    <ChevronDown className={`h-4 w-4 text-slate-400 transition-all ${isOpen ? 'rotate-180 text-sky-500' : ''}`} />
                  </button>

                  {isOpen && (
                    <div className="bg-slate-50/50 rounded-xl mt-1 py-1 px-2.5 space-y-1.5 animate-fadeIn">
                      <a
                        href={`#${curtain.parentPath}`}
                        onClick={() => setMobileMenuOpen(false)}
                        className="block py-2.5 px-3 rounded-lg text-xs font-black text-sky-600 border-l-2 border-sky-400 bg-sky-50/40"
                      >
                        Общий обзор раздела &rarr;
                      </a>
                      {isPracticesTab ? (
                        /* Render the 4 main mobile practices as nested accordions */
                        MAIN_MOBILE_PRACTICES.map((practice) => {
                          const isSubOpen = !!openMobileSubpractices[practice.key];
                          return (
                            <div key={practice.key} className="border-b border-slate-100/50 pb-1 last:border-0 last:pb-0">
                              <button
                                onClick={(e) => toggleMobileSubpractice(practice.key, e)}
                                className="w-full flex items-center justify-between py-2 px-3 rounded-lg text-xs font-bold text-slate-700 hover:text-slate-900 border-l-2 border-transparent hover:border-sky-500 hover:bg-slate-50 transition-all text-left"
                              >
                                <span>{practice.name}</span>
                                <ChevronDown className={`h-3.5 w-3.5 text-slate-400 transition-all ${isSubOpen ? 'rotate-180 text-sky-500' : ''}`} />
                              </button>

                              {isSubOpen && (
                                <div className="pl-4 pr-1 mt-1 space-y-1 bg-white/70 py-1.5 rounded-lg border border-slate-100/60 shadow-xs animate-fadeIn">
                                  {practice.vuzes.map((vuzItem) => (
                                    <a
                                      key={vuzItem.path}
                                      href={`#${vuzItem.path}`}
                                      onClick={() => setMobileMenuOpen(false)}
                                      className="block py-2 px-3 rounded-md text-[11px] font-semibold text-slate-600 hover:text-sky-600 hover:bg-slate-50 transition-all border-l-2 border-transparent hover:border-sky-500"
                                    >
                                      {vuzItem.name}
                                    </a>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })
                      ) : (
                        /* Standard subcategory render */
                        curtain.items.map((subItem) => (
                          <a
                            key={subItem.path}
                            href={`#${subItem.path}`}
                            onClick={() => setMobileMenuOpen(false)}
                            className="block py-2.5 px-3 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 border-l-2 border-transparent hover:border-sky-500 hover:bg-slate-50 transition-all"
                          >
                            {subItem.name}
                          </a>
                        ))
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Quick Consultation Messengers (Mobile view) */}
          <div className="border-t border-slate-100 pt-4 px-1 space-y-3">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block pb-1">
              Напишите нам напрямую:
            </span>
            <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-bold">
              <a
                href={CONTACT_INFO.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-all"
              >
                <div className="h-8 w-8 rounded-lg bg-[#25D366] text-white flex items-center justify-center shadow-xs">
                  <svg className="h-4.5 w-4.5 fill-current" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.458 5.705 1.459h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                  </svg>
                </div>
                <span>WhatsApp</span>
              </a>
              <a
                href={CONTACT_INFO.telegram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl bg-sky-50 text-sky-700 hover:bg-sky-100 transition-all"
              >
                <div className="h-8 w-8 rounded-lg bg-[#0088cc] text-white flex items-center justify-center shadow-xs">
                  <svg className="h-4.5 w-4.5 fill-current" viewBox="0 0 24 24">
                    <path d="M11.944 0a12 12 0 1012 11.944A12 12 0 0011.944 0zm5.556 8.333l-1.91 9a.53.53 0 01-.772.394l-2.92-2.15-1.41 1.36a.375.375 0 01-.624-.183l-.94-3.1-2.73-.85a.372.372 0 01-.013-.7l10.8-4.16a.374.374 0 01.519.389z" />
                  </svg>
                </div>
                <span>Telegram</span>
              </a>
              <a
                href={CONTACT_INFO.max}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 transition-all"
              >
                <div className="h-8 w-8 rounded-lg bg-[#8A2BE2] text-white flex items-center justify-center font-black text-sm shadow-xs">
                  М
                </div>
                <span>MAX.ru</span>
              </a>
            </div>
          </div>

          {/* Call / Mail Links */}
          <div className="border-t border-slate-100 pt-4 px-3 space-y-3.5">
            <div className="flex flex-col gap-2">
              <a
                href={`tel:${CONTACT_INFO.primaryPhoneLink}`}
                className="flex items-center gap-2.5 font-black text-slate-950 text-base"
              >
                <Phone className="h-5 w-5 text-sky-500" />
                {CONTACT_INFO.primaryPhone}
              </a>
              <a
                href={`mailto:${CONTACT_INFO.email}`}
                className="flex items-center gap-2.5 font-semibold text-slate-500 text-sm"
              >
                <Mail className="h-5 w-5 text-sky-500" />
                {CONTACT_INFO.email}
              </a>
            </div>
          </div>

        </div>
      )}
    </header>
  );
}

